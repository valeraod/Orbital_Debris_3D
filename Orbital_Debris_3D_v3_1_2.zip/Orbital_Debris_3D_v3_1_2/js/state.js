// ══════════════════════════════════════════════════════════════════════════════
// STATE — глобальные переменные состояния симулятора // ── [v2.13.3]
// Загружается ДО scene3d.js (который использует RORB при инициализации).
// Classic script — все объявления глобальные.
// ══════════════════════════════════════════════════════════════════════════════

// Orbital / физические параметры
let objMass = 200;
let BCOEF   = objMass / (CD * AREA);
let orbInclDeg=0;
let HORB=500e3, RORB=RE+HORB;
let V0=Math.sqrt(GM/RORB);
let T0=2*Math.PI*Math.sqrt(RORB**3/GM);
let NFRAG=200;
let atmoEnabled=true;

// Sim runtime
let simTime=0, running=false, exploded=false, explodeTime=0;
let rafId=null, lastTs=null, simSpeed=300;
let dvMag=500;
let launchDv=0;
let frags=[];
let aliveCount=0;
let fastForward=false;
let pendingExplode=false;
let focusMode=false;
let showAllOrbits=false;
let selectedFrag=null;
let selectedMain=false;
let simState='idle';
let mainObj=null;
let is2D=false;
let showFrags=true;     // видимость осколков (чекбокс «Осколки»)
let cloudSizePx=2;      // размер частиц облака, px (слайдер «Облако»)

// Константы рантайма
const SIM_INTERVAL=16;
const SUB_STEPS=10;
const TRAIL_LEN=18;
const ENERGY_CORRECT_INTERVAL=500;
let _skipStepCount=0;
let _skipAbort=false;
let _skipDropToRealtime=false;

// RK4 output buffer
const _rk4out=new Float64Array(6);
