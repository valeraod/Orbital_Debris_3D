// ══════════════════════════════════════════════════════════════════════════════
// UI — HUD updates, controls, mode-switch, lock/unlock, skip-time // ── [v3.0.3]
// Classic script (no ES modules) — declarations are global.
// Зависит от: physics.js (orbitalElements3D, RE, GM, RORB, CD, AREA),
// scene3d.js (updateRefOrbit, camDistMatch, updateCamera, buildMainTrailLine,
//   fragMeshes, trailLines, mainTrailLine, selOrbitLine, mainOrbitLine,
//   mainOrbitFrozen, scene, mainMesh, mainGlowMesh, clearAllOrbitLines3D,
//   camTheta, camPhi, camDist, camTargetX/Y/Z, camera, _CAM_K),
// scene2d.js (S2_0, W2, H2, zoom2, camX2, camY2, resize2D, frozenMainOrbit2D).
// Глобальные переменные состояния и render/loop — в index.html (до stage 7).
// ══════════════════════════════════════════════════════════════════════════════
function updateStats(){
  if(!exploded)return;
  const total=frags.length;
  let beyondCount=0,escapedCount=0,deorbitCount=0;
  let maxApo=-Infinity,minPer=Infinity;
  for(const f of frags){
    if(f.alive){
      if(f.beyond)beyondCount++;
      if(f.maxR>maxApo)maxApo=f.maxR;
      if(f.minR<minPer)minPer=f.minR;
    } else {
      if(f.escaped)escapedCount++;
      else deorbitCount++;
    }
  }
  const onOrbit=aliveCount-beyondCount;
  document.getElementById('sp-alive').textContent=onOrbit;
  document.getElementById('sp-total').textContent=total;
  const pct=total>0?(onOrbit/total*100):100;
  document.getElementById('sp-bar').style.width=pct+'%';
  document.getElementById('sp-beyond').textContent=beyondCount;
  document.getElementById('sp-dead').textContent=deorbitCount;
  document.getElementById('sp-escaped').textContent=escapedCount;
  document.getElementById('sp-apo').textContent=maxApo>-Infinity?Math.round((maxApo-RE)/1000).toLocaleString('ru-RU'):'—';
  document.getElementById('sp-per').textContent=minPer<Infinity?Math.round((minPer-RE)/1000).toLocaleString('ru-RU'):'—';
}

function formatTime(sec){
  const totalMin=Math.floor(sec/60);
  const h=Math.floor(totalMin/60),m=totalMin%60;
  const d=Math.floor(h/24),hd=h%24;
  const y=Math.floor(d/365),dy=d%365;
  if(y>0)return`${y} г. ${dy} д. ${hd} ч. ${m} мин`;
  if(d>0)return`${d} д. ${hd} ч. ${m} мин`;
  if(h>0)return`${h} ч. ${m} мин`;
  return`${totalMin} мин`;
}

// updateFragInfo — обновление HUD-блока инфо об орбите выбранного объекта (мина/осколок)
function updateFragInfo(){
  const infoEl=document.getElementById('hud-obj-info');
  // Determine target: selected frag or mainObj
  let el=null, apo=null, per=null;
  if(selectedFrag!==null&&frags[selectedFrag]&&frags[selectedFrag].alive){
    const f=frags[selectedFrag];
    el=orbitalElements3D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
    apo=el&&!el.hyperbolic?Math.round((f.maxR-RE)/1000):null;
    per=el?Math.round((f.minR-RE)/1000):null;
  } else if(selectedMain&&mainObj&&mainObj.alive){
    el=orbitalElements3D(mainObj.x,mainObj.y,mainObj.z,mainObj.vx,mainObj.vy,mainObj.vz);
    apo=el&&!el.hyperbolic?Math.round((mainObj.maxR-RE)/1000):null;
    per=el?Math.round((mainObj.minR-RE)/1000):null;
  }
  if(!el){infoEl.style.display='none';updateFocusBtn();return;}
  infoEl.style.display='';
  document.getElementById('hh-apo').textContent=el.hyperbolic?'∞':(apo!==null?apo.toLocaleString('ru-RU'):'—');
  document.getElementById('hh-per').textContent=per!==null?per.toLocaleString('ru-RU'):'—';
  document.getElementById('hh-inc').textContent=el.inc.toFixed(1);
  document.getElementById('hh-ecc').textContent=el.e.toFixed(4);
  updateFocusBtn();
}


function toggle2D(){
  is2D=!is2D;
  document.getElementById('bMode').textContent=is2D?'⬡ 3D':'⬡ 2D';
  document.getElementById('c3d').style.display=is2D?'none':'block';
  document.getElementById('c2d').style.display=is2D?'block':'none';
  document.getElementById('hud-zoom').style.display=is2D?'':'none';
  if(is2D){
    resize2D();
    // reset 2D view to fit current orbit
    zoom2=1.0; camX2=0; camY2=0;
  } else {
    const cw=document.getElementById('cw');
    camera.aspect=(cw.offsetWidth||1)/(cw.offsetHeight||1);
    camera.updateProjectionMatrix();
  }
}

function fullView(){
  if(!exploded||frags.length===0){
    // Before explosion: fit mainObj or default
    if(is2D){
      zoom2=1.0;camX2=0;camY2=0;
    } else {
      camTargetX=0;camTargetY=0;camTargetZ=0;
      camTheta=0;camPhi=Math.PI/4;
      window._camUserZoomed=true;
      camDist=RORB*2.5;
      updateCamera();
    }
    return;
  }

  // Collect alive fragment positions
  const pts=[];
  for(const f of frags){
    if(!f.alive||f.beyond)continue;
    pts.push([f.x,f.y,f.z]);
  }
  // Always include Earth center
  pts.push([0,0,0]);

  if(pts.length===1){
    // Only Earth
    if(is2D){zoom2=1.0;camX2=0;camY2=0;}
    else{camTargetX=0;camTargetY=0;camTargetZ=0;camDist=RORB*2.5;window._camUserZoomed=true;updateCamera();}
    return;
  }

  if(showAllOrbits){
    // Extend pts with apocenter positions (elliptic) or current position capped at R_OBS (hyperbolic)
    for(const f of frags){
      if(!f.alive||f.beyond)continue;
      const el=orbitalElements3D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
      if(!el)continue;
      if(el.hyperbolic){
        // For hyperbolic use current position — it's already the farthest we'll track
        pts.push([f.x,f.y,f.z]);
      } else {
        if(!isFinite(el.ra)||el.a>1e9)continue;
        const eMag=Math.sqrt(el.ex*el.ex+el.ey*el.ey+el.ez*el.ez)||1;
        const ax=-el.a*(1+el.e)*el.ex/eMag;
        const ay=-el.a*(1+el.e)*el.ey/eMag;
        const az=-el.a*(1+el.e)*el.ez/eMag;
        pts.push([ax,ay,az]);
      }
    }
  }

  // Bounding box — always include Earth surface
  let minX=Infinity,minY=Infinity,minZ=Infinity;
  let maxX=-Infinity,maxY=-Infinity,maxZ=-Infinity;
  for(const [x,y,z] of pts){
    if(!isFinite(x)||!isFinite(y)||!isFinite(z))continue;
    if(x<minX)minX=x; if(x>maxX)maxX=x;
    if(y<minY)minY=y; if(y>maxY)maxY=y;
    if(z<minZ)minZ=z; if(z>maxZ)maxZ=z;
  }
  minX=Math.min(minX,-RE);minY=Math.min(minY,-RE);minZ=Math.min(minZ,-RE);
  maxX=Math.max(maxX, RE);maxY=Math.max(maxY, RE);maxZ=Math.max(maxZ, RE);

  const cx=(minX+maxX)/2, cy=(minY+maxY)/2, cz=(minZ+maxZ)/2;
  const dx=maxX-minX, dy=maxY-minY, dz=maxZ-minZ;
  const halfDiag=Math.sqrt(dx*dx+dy*dy+dz*dz)/2;

  if(is2D){
    // 2D: fit bounding box in XZ plane, center on bbox center
    const dxz=Math.max(dx, dz)*1.1;
    const s0=S2_0();
    zoom2=Math.max(0.05,Math.min(20, (Math.min(W2,H2)*0.44)/(s0*dxz*0.5)));
    const s=s0*zoom2;
    camX2= cz*s;
    camY2=-cx*s;
  } else {
    window._camUserZoomed=true;
    camTargetX=cx;camTargetY=cy;camTargetZ=cz;
    camTheta=0;camPhi=Math.PI/4;
    camDist=halfDiag*2.4;
    updateCamera();
  }
}

function setFocusMode(on){
  focusMode=on;
  const btn=document.getElementById('bFocus');
  if(on) btn.classList.add('active');
  else btn.classList.remove('active');
  if(!on) fullView();
}

function updateFocusBtn(){
  const btn=document.getElementById('bFocus');
  const hasTarget=(selectedFrag!==null&&frags[selectedFrag]&&frags[selectedFrag].alive)
                ||(selectedMain&&mainObj&&mainObj.alive);
  btn.disabled=!hasTarget;
  if(!hasTarget&&focusMode) setFocusMode(false);
  for(const f of frags) f._lastColor=-1;
}
const LOCKABLE=['nAlt','nFrag','sDv','sLaunchDv','nMass','selIncl','selDvDist'];
const LOCK_GROUPS=['grpAlt','grpFrag','grpDv','grpLaunchDv','grpMass','grpDvDist','grpIncl'];
function lockParams(){LOCKABLE.forEach(id=>{document.getElementById(id).disabled=true;});LOCK_GROUPS.forEach(id=>{document.getElementById(id).classList.add('locked');});}
function unlockParams(){LOCKABLE.forEach(id=>{document.getElementById(id).disabled=false;});LOCK_GROUPS.forEach(id=>{document.getElementById(id).classList.remove('locked');});}

function setSimState(state){
  simState=state;
  const btn=document.getElementById('bPlay');
  if(state==='idle'){btn.textContent='▶ Старт';running=false;unlockParams();}
  else if(state==='running'){btn.textContent='⏸ Пауза';running=true;}
  else if(state==='paused'){btn.textContent='▶ Далее';running=false;}
}

function applyOrbitalParams(){
  const altKm=parseFloat(document.getElementById('nAlt').value)||500;
  const nf=Math.max(36,Math.min(1000,parseInt(document.getElementById('nFrag').value)||36));
  document.getElementById('nFrag').value=nf;
  const mass=Math.max(1,Math.min(100000,parseFloat(document.getElementById('nMass').value)||100));
  document.getElementById('nMass').value=mass;
  objMass=mass;
  BCOEF=objMass/(CD*AREA);
  HORB=Math.max(150e3,altKm*1e3);
  RORB=RE+HORB;
  V0=Math.sqrt(GM/RORB);
  T0=2*Math.PI*Math.sqrt(RORB**3/GM);
  NFRAG=Math.max(36,Math.min(1000,nf));
  updateRefOrbit();
  window._camUserZoomed=false; camDist=camDistMatch();
  updateCamera();
  zoom2=1.0; camX2=0; camY2=0;
}


document.getElementById('bPlay').onclick=function(){
  if(simState==='idle'){
    applyOrbitalParams();lockParams();
    initMainObj();buildMainTrailLine();
    setSimState('running');lastTs=null;
    rafId=setTimeout(loop,SIM_INTERVAL);
  } else if(simState==='running'){
    clearTimeout(rafId);setSimState('paused');
  } else if(simState==='paused'){
    setSimState('running');lastTs=null;rafId=setTimeout(loop,SIM_INTERVAL);
  }
};

document.getElementById('bReset').onclick=function(){
  clearTimeout(rafId);
  exploded=false;explodeTime=0;simTime=0;frags=[];aliveCount=0;selectedFrag=null;selectedMain=false;mainObj=null;pendingExplode=false;focusMode=false;showAllOrbits=false;
  document.getElementById('bFocus').disabled=true;
  document.getElementById('bFocus').classList.remove('active');
  document.getElementById('bAllOrbits').classList.remove('active');
  clearAllOrbitLines3D();
  fragMeshes.forEach(m=>{m.material.dispose();scene.remove(m);});fragMeshes.length=0;
  trailLines.forEach(l=>{l.geometry.dispose();l.material.dispose();scene.remove(l);});trailLines.length=0;
  if(mainTrailLine){mainTrailLine.geometry.dispose();mainTrailLine.material.dispose();scene.remove(mainTrailLine);mainTrailLine=null;}
  if(selOrbitLine){scene.remove(selOrbitLine);selOrbitLine=null;}
  if(mainOrbitLine){mainOrbitLine.geometry.dispose();mainOrbitLine.material.dispose();scene.remove(mainOrbitLine);mainOrbitLine=null;}
  mainOrbitFrozen=false;
  frozenMainOrbit2D=null;
  dcReset();
  document.getElementById('bBoom').disabled=false;
  document.getElementById('stats-panel').classList.remove('visible');
  document.getElementById('hud-obj-info').style.display='none';
  if(is2D){is2D=false;document.getElementById('bMode').textContent='⬡ 2D';
    document.getElementById('c3d').style.display='block';
    document.getElementById('c2d').style.display='none';
    document.getElementById('hud-zoom').style.display='none';
  }
  zoom2=1.0;camX2=0;camY2=0;
  document.getElementById('nAlt').value=500;
  document.getElementById('nFrag').value=200;
  document.getElementById('sDv').value=500;
  document.getElementById('lDv').textContent='500 м/с';
  document.getElementById('bMode').disabled=false;
  document.getElementById('sSize').value=2.5;
  document.getElementById('lSize').textContent='2.5';
  objSizePx=2.5;
  document.getElementById('sCloudSize').value=2;
  document.getElementById('lCloudSize').textContent='2';
  cloudSizePx=2;
  document.getElementById('sLaunchDv').value=0;
  document.getElementById('lLaunchDv').textContent='0 м/с';
  document.getElementById('nMass').value=200;
  document.getElementById('sSpd').value=300;
  document.getElementById('lSpd').textContent='300×';
  dvMag=500;launchDv=0;objMass=200;BCOEF=objMass/(CD*AREA);simSpeed=300;
  HORB=500e3;RORB=RE+HORB;
  V0=Math.sqrt(GM/RORB);T0=2*Math.PI*Math.sqrt(RORB**3/GM);NFRAG=200;
  orbInclDeg=0;document.getElementById('selIncl').value='0';
  updateRefOrbit();
  initMainObj();
  mainMesh.visible=true;mainGlowMesh.visible=true;
  camTheta=0;camPhi=Math.PI/4;window._camUserZoomed=false; camDist=camDistMatch();camTargetX=0;camTargetY=0;camTargetZ=0;updateCamera();
  setSimState('idle');
};

document.getElementById('bBoom').onclick=function(){
  if(simState==='idle'){
    applyOrbitalParams();lockParams();
    initMainObj();buildMainTrailLine();
    pendingExplode=true;
    setSimState('running');lastTs=null;
    rafId=setTimeout(loop,SIM_INTERVAL);
  } else if(simState==='paused'){
    setSimState('running');lastTs=null;rafId=setTimeout(loop,SIM_INTERVAL);
    explode();
  } else {
    explode();
  }
};

document.getElementById('bView').onclick=function(){
  if(is2D){zoom2=1.0;camX2=0;camY2=0;}
  else{camTheta=0;camPhi=Math.PI/4;window._camUserZoomed=false; camDist=camDistMatch();camTargetX=0;camTargetY=0;camTargetZ=0;updateCamera();}
};

document.getElementById('bFull').onclick=function(){
  setFocusMode(false);
  fullView();
};

document.getElementById('bFocus').onclick=function(){
  if(focusMode) setFocusMode(false);
  else if(selectedFrag!==null&&frags[selectedFrag]&&frags[selectedFrag].alive) setFocusMode(true);
};

document.getElementById('bAllOrbits').onclick=function(){
  showAllOrbits=!showAllOrbits;
  this.classList.toggle('active',showAllOrbits);
  if(!showAllOrbits)clearAllOrbitLines3D();
};

document.getElementById('bMode').onclick=function(){toggle2D();};

document.getElementById('sSpd').oninput=function(){
  simSpeed=+this.value;document.getElementById('lSpd').textContent=this.value+'×';
};
document.getElementById('sDv').oninput=function(){
  dvMag=+this.value;document.getElementById('lDv').textContent=this.value+' м/с';
};
document.getElementById('sSize').oninput=function(){
  objSizePx=+this.value;document.getElementById('lSize').textContent=this.value;
};
document.getElementById('sCloudSize').oninput=function(){
  cloudSizePx=+this.value;
  document.getElementById('lCloudSize').textContent=this.value;
  if(typeof dcSetPointSize==='function')dcSetPointSize(cloudSizePx);
};
document.getElementById('sLaunchDv').oninput=function(){
  launchDv=+this.value;
  document.getElementById('lLaunchDv').textContent=(launchDv>=0?'+':'')+launchDv+' м/с';
};
document.getElementById('nAlt').onblur=function(){
  let v=parseInt(this.value)||500;v=Math.max(150,Math.min(2000,v));this.value=v;
};
document.getElementById('nFrag').onblur=function(){
  let v=parseInt(this.value)||36;v=Math.max(36,Math.min(1000,v));this.value=v;
};
document.getElementById('nMass').onblur=function(){
  let v=parseFloat(this.value)||100;v=Math.max(1,Math.min(100000,v));this.value=v;
};
document.getElementById('cbAtmo').onchange=function(){atmoEnabled=this.checked;};

document.getElementById('selIncl').onchange=function(){
  if(exploded||simState!=='idle')return;
  orbInclDeg=parseFloat(this.value)||0;
  simTime=0;
  initMainObj();
  updateRefOrbit();
  updateMainOrbitLine();
  // 2D доступен только при наклонении 0°
  const btn2D=document.getElementById('bMode');
  if(orbInclDeg!==0){
    if(is2D)toggle2D(); // переключить в 3D если был в 2D
    btn2D.disabled=true;
    btn2D.title='2D доступен только при наклонении 0°';
  } else {
    btn2D.disabled=false;
    btn2D.title='';
  }
};

document.getElementById('cbFrags').onchange=function(){
  showFrags=this.checked;
};

document.getElementById('cbCloud').onchange=function(){
  dcSetVisible(this.checked);
};

document.getElementById('bSkip').onclick=async function(){
  const n=parseFloat(document.getElementById('nSkip').value)||1;
  const mult=parseFloat(document.getElementById('selSkip').value);
  const totalSec=n*mult*86400;
  const wasRunning=running;
  if(wasRunning){clearTimeout(rafId);running=false;}
  const btn=document.getElementById('bSkip');
  const btnStop=document.getElementById('bSkipStop');
  btn.disabled=true;btn.textContent='⏳ 0%';
  btnStop.disabled=false;
  _skipAbort=false;
  _skipDropToRealtime=false;
  fastForward=true;
  _skipStepCount=0;
  let elapsed=0;
  const startSimTime=simTime;
  const CHUNK_SEC=30000;
  const totalChunks=Math.ceil(totalSec/CHUNK_SEC);
  let chunksDone=0;
  while(elapsed<totalSec){
    if(_skipAbort)break;
    const chunkEnd=Math.min(elapsed+CHUNK_SEC,totalSec);
    if(exploded){
      // Аналитический шаг: вычисляем позиции всех осколков на момент t1
      const t1=startSimTime+chunkEnd;
      for(const f of frags){
        if(!f.alive)continue;
        if(f.orb){
          const pos=orbitPosAtTime(f.orb,t1,atmoEnabled);
          if(!pos){
            if(!f.escaped){aliveCount--;}
            f.alive=false;f.escaped=false;
          } else {
            const r=Math.sqrt(pos.x*pos.x+pos.y*pos.y+pos.z*pos.z);
            if(r<RE){
              if(!f.escaped){aliveCount--;}
              f.alive=false;f.escaped=false;
            } else {
              f.beyond=(r>R_OBS);
              f.x=pos.x;f.y=pos.y;f.z=pos.z;
              if(pos.vx!==undefined){f.vx=pos.vx;f.vy=pos.vy;f.vz=pos.vz;}
              if(r>f.maxR&&r<R_OBS*2)f.maxR=r;
              if(r<f.minR&&!f.beyond)f.minR=r;
            }
          }
        } else {
          // Нет орбитальных элементов — RK4
          const dt=chunkEnd-elapsed;
          const nsub=Math.ceil(dt/60);
          const dts=dt/nsub;
          let{x,y,z,vx,vy,vz}=f;
          let dead=false;
          for(let s=0;s<nsub;s++){
            rk4(x,y,z,vx,vy,vz,dts,true,_rk4out,atmoEnabled,BCOEF);
            x=_rk4out[0];y=_rk4out[1];z=_rk4out[2];
            vx=_rk4out[3];vy=_rk4out[4];vz=_rk4out[5];
            const r=Math.sqrt(x*x+y*y+z*z);
            if(r<RE){f.alive=false;f.escaped=false;aliveCount--;dead=true;break;}
          }
          if(!dead){f.x=x;f.y=y;f.z=z;f.vx=vx;f.vy=vy;f.vz=vz;}
        }
      }
      elapsed=chunkEnd;
      simTime=startSimTime+elapsed;
      dcStepAnalytical(simTime);
    } else {
      // До взрыва — RK4
      while(elapsed<chunkEnd){
        const dt=Math.min(adaptiveSkipDt(),chunkEnd-elapsed);
        stepMainObj(dt);
        simTime+=dt;
        elapsed+=dt;
        _skipStepCount++;
      }
    }
    chunksDone++;
    btn.textContent=`⏳ ${Math.round(Math.min(chunksDone,totalChunks)/totalChunks*100)}%`;
    await new Promise(r=>setTimeout(r,0));
  }
  if(exploded)updateStats();
  fastForward=false;
  _skipAbort=false;
  btnStop.disabled=true;
  btn.disabled=false;
  if(_skipDropToRealtime){
    // Переключиться в реальное время на 5×
    _skipDropToRealtime=false;
    btn.textContent='⏩';
    simSpeed=5;
    document.getElementById('sSpd').value=5;
    document.getElementById('lSpd').textContent='5×';
    running=true;lastTs=null;setSimState('running');rafId=setTimeout(loop,SIM_INTERVAL);
  } else {
    btn.textContent='⏩';
    if(wasRunning){running=true;lastTs=null;rafId=setTimeout(loop,SIM_INTERVAL);}
  }
};

document.getElementById('bSkipStop').onclick=function(){
  _skipAbort=true; // сигнал выйти из skip-loop
  // после выхода из loop — запустить реальное время на 5×
  _skipDropToRealtime=true;
};
