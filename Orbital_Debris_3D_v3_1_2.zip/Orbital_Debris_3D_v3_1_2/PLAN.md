# ПЛАН РАЗРАБОТКИ — Orbital Debris 3D v2.12+

Документ для передачи между агентами. Содержит правила, контекст, этапы и статус выполнения.

---

## КОНТЕКСТ И ПРАВИЛА

### Версионирование
Формат `X.Y.Z`:
- **X** — смена архитектуры или принципа работы (например, переход на аналитическую модель)
- **Y** — завершение этапа из раздела «ЭТАПЫ» (Этап 1 → v2.13, Этап 2 → v2.14, ...)
- **Z** — правки/доработки внутри текущего этапа: v2.13.1, v2.13.2, ...
- Версии должны быть **уникальны** — повторное использование недопустимо
- Версия проставляется везде: `<title>` в index.html, комментарий в изменённых JS-файлах (`// ── [vX.Y.Z]`), имя папки и архива, CHANGELOG.md

### Структура проекта
```
Orbital_Debris_3D_vX_Y_Z_RELEASE/
  index.html       — UI, разметка, подключение скриптов
  css/
    base.css       — базовые стили
    hud.css        — HUD
    controls.css   — панель управления
  js/
    physics.js     — чистые функции: rk4, airDensity, orbitalElements3D/2D,
                     mulberry32, adaptiveSubs, solveKepler (будет добавлена),
                     orbitPosAtTime (будет добавлена), massToBC (будет добавлена)
    state.js       — глобальные переменные симуляции (загружается первым)
    scene3d.js     — Three.js: Земля, звёзды, меши осколков, орбитные линии, камера
    scene2d.js     — 2D canvas: проекция орбит
    ui.js          — HUD, stats-panel, кнопки, skip-time
    input.js       — мышь, тач, pick
    main.js        — игровой цикл, explode(), stepFrags(), stepMainObj()
  PLAN.md          — этот файл
  CHANGELOG.md
```

### Координатная система
- Физика: ECI, Z-up (совпадает с осью вращения Земли)
- Three.js: Y-up. Маппинг: `physics(x,y,z) → THREE.Vector3(x, z, -y)`
- 2D canvas: проекция на плоскость XZ (экваториальная)

### Глобальные переменные (state.js)
```js
let objMass, BCOEF, HORB, RORB, V0, T0, NFRAG, atmoEnabled;
let simTime, running, exploded, explodeTime;
let rafId, lastTs, simSpeed, dvMag, launchDv;
let frags[], aliveCount;
let fastForward, pendingExplode, focusMode, showAllOrbits;
let selectedFrag, selectedMain, simState, mainObj, is2D;
const SIM_INTERVAL, SUB_STEPS, TRAIL_LEN, ENERGY_CORRECT_INTERVAL;
```

### Архитектура физики (важно!)
Сейчас все осколки интегрируются через **RK4** с J2-возмущением в каждом шаге. Это точно для краткосрочной физики, но при перемотке на месяцы/годы:
- Прецессия RAAN (Ω) и аргумента перигея (ω) накапливается корректно через J2-силу в RK4
- Проблема: при больших `dt` (skip-time) шаги крупные, численная ошибка растёт
- Star Destroyer решает это аналитической моделью в `orbitPosAtTime` — хранит орбитальные элементы и считает позицию аналитически, отдельно от RK4

**Решение для Orbital Debris (Этап 1):** добавить `solveKepler` + `orbitPosAtTime` в physics.js. При skip-time использовать аналитику вместо RK4, при реальном времени — оставить RK4 (для точных траекторий).

### Правила модификации
- `physics.js` — только чистые функции, без DOM и без обращений к глобальному состоянию
- `state.js` — только объявления переменных, без логики
- Не трогать CSS без необходимости
- Каждый этап — атомарный: после него симулятор должен работать

---

## ТЕКУЩЕЕ СОСТОЯНИЕ (v2.12)

### Что реализовано
- RK4-интегратор с J2 и 14-слойной атмосферой
- 3 распределения Δv: равномерное, экспоненциальное, Максвелл–Больцман
- 3D (Three.js) и 2D (canvas) режимы просмотра
- HUD: время, виток, высота, скорость, апогей/перигей, наклонение, эксцентриситет
- Stats-panel: живые/деорбитировавшие/улетевшие осколки
- Перемотка (skip-time) с прогресс-баром
- Фокус на осколке, показ всех орбит
- Коррекция энергии при выключенной атмосфере

### Чего не хватает
- **Нет кнопки «Стоп» для прерывания перемотки** — при перемотке на 100 лет нельзя остановить
- **Нет аналитической модели орбиты** — при skip-time используется грубый RK4
- **Нет прецессии RAAN при skip-time** — облако не расслаивается в тор
- **Нет массового распределения осколков** — все осколки одинаковой массы (BCOEF одинаков)
- **Нет экспорта данных**
- **Нет реальных TLE-данных**
- **Нет пресетов реальных событий**

---

## ЭТАПЫ

### Этап 1 — Прерывание перемотки + аналитика орбит → v2.13
**Приоритет: высокий. Самое заметное улучшение UX.**

#### 1а. Кнопка «Стоп» для перемотки
**Файлы:** `index.html`, `css/controls.css`, `js/ui.js`, `js/state.js`

- Добавить глобальный флаг `let _skipAbort = false;` в `state.js`
- Добавить кнопку `<button id="bSkipStop" disabled>✕</button>` рядом с `bSkip` в `index.html`
- В `bSkip.onclick`: перед каждым `await` проверять `if(_skipAbort){break;}`, по завершению сбрасывать `_skipAbort=false`
- `bSkipStop.onclick`: `_skipAbort=true;`
- Активировать `bSkipStop` при старте перемотки, деактивировать по завершению/прерыванию
- После прерывания показать текст типа `⏹ Прервано: X д. из Y д.` в кнопке `bSkip`
- Стиль `#bSkipStop`: красноватый акцент, как у кнопки `bReset`

#### 1б. Аналитическая модель + прецессия RAAN для skip-time
**Файлы:** `js/physics.js`, `js/state.js`, `js/main.js`

**В `physics.js` добавить:**

```js
// Кеплерово уравнение — итерация Ньютона
function solveKepler(M, e) {
  let E = M;
  for (let k = 0; k < 8; k++) {
    const dE = (M - (E - e * Math.sin(E))) / (1 - e * Math.cos(E));
    E += dE;
    if (Math.abs(dE) < 1e-10) break;
  }
  return E;
}

// Аналитическое распространение орбиты с J2-прецессией
// orb: { a, e, i, Om, om, M0, spawnT, bcoef }
// t: текущее время симуляции (сек)
// Возвращает {x,y,z} в ECI или null если деорбитировал
function orbitPosAtTime(orb, t) {
  const { a, e, i, Om, om, M0, spawnT, bcoef } = orb;
  if (a <= 0 || e >= 1) return null;
  const dt = t - spawnT;
  if (dt < 0) return null;

  // Атмосферное торможение: упрощённая аналитика через перигей
  const rp = a * (1 - e);
  const rho_p = airDensity(rp - RE);
  const v_orb = Math.sqrt(GM / a);
  const da = atmoEnabled ? -(rho_p * v_orb * a / bcoef) * dt : 0;
  const a2 = a + da;
  if (a2 <= 0) return null;
  const e2 = Math.max(0, e * (a2 / a));
  const rp2 = a2 * (1 - e2);
  if (rp2 < RE + 50e3) return null; // деорбитировал

  // Средняя аномалия
  const n = Math.sqrt(GM / (a2 * a2 * a2));
  const TWO_PI = 2 * Math.PI;
  const M = ((M0 + n * dt) % TWO_PI + TWO_PI) % TWO_PI;

  // J2-прецессия RAAN и аргумента перигея
  const cosI = Math.cos(i), sinI = Math.sin(i);
  const p = a2 * (1 - e2 * e2);
  const j2rate = 1.5 * n * J2 * (RE / p) * (RE / p);
  const dOm = -j2rate * cosI * dt;          // прецессия RAAN (Ω̇)
  const dom = j2rate * (2.5 * sinI * sinI - 2) * dt; // прецессия ω
  const Om2 = Om + dOm;
  const om2 = om + dom;

  // Кеплерово уравнение → истинная аномалия
  const E = solveKepler(M, e2);
  const nu = 2 * Math.atan2(
    Math.sqrt(1 + e2) * Math.sin(E / 2),
    Math.sqrt(1 - e2) * Math.cos(E / 2)
  );
  const r = a2 * (1 - e2 * Math.cos(E));

  // Перекоэффициенты Гаусса → ECI
  const cosOm = Math.cos(Om2), sinOm = Math.sin(Om2);
  const cosI2 = Math.cos(i), sinI2 = Math.sin(i);
  const coso = Math.cos(om2), sino = Math.sin(om2);
  const Px = cosOm * coso - sinOm * sino * cosI2;
  const Py = sinOm * coso + cosOm * sino * cosI2;
  const Pz = sino * sinI2;
  const Qx = -cosOm * sino - sinOm * coso * cosI2;
  const Qy = -sinOm * sino + cosOm * coso * cosI2;
  const Qz = coso * sinI2;
  const xOrb = r * Math.cos(nu), yOrb = r * Math.sin(nu);
  return {
    x: xOrb * Px + yOrb * Qx,
    y: xOrb * Py + yOrb * Qy,
    z: xOrb * Pz + yOrb * Qz,
  };
}

// Баллистический коэффициент из массы (сфера, средняя плотность 200 кг/м³)
function massToBC(m) { return m / (CD * Math.pow(m / 200, 2 / 3)); }
```

**В `state.js`:** добавить `let _skipAbort = false;`

**В `main.js`:** при `explode()` — для каждого осколка сохранять орбитальные элементы в `f.orb`:
```js
// После spawn frag — вычислить орбитальные элементы и сохранить
const el = orbitalElements3D(fx, fy, fz, fvx, fvy, fvz);
f.orb = el ? {
  a: el.a, e: el.e,
  i: Math.acos(Math.max(-1, Math.min(1, el.hz / Math.sqrt(el.hx*el.hx+el.hy*el.hy+el.hz*el.hz)))),
  Om: Math.atan2(el.hx, -el.hy), // RAAN из вектора момента
  om: Math.atan2(el.ez, el.ex),   // аргумент перигея из эксцентр. вектора
  M0: 0,
  spawnT: simTime,
  bcoef: BCOEF,
} : null;
```

**В `ui.js` skip-loop:** заменить `stepFrags(dt)` на аналитический шаг:
```js
// В skip-loop: для каждого живого осколка
for (const f of frags) {
  if (!f.alive || !f.orb) continue;
  const pos = orbitPosAtTime(f.orb, simTime);
  if (!pos) { f.alive = false; aliveCount--; continue; }
  f.x = pos.x; f.y = pos.y; f.z = pos.z;
  // обновить maxR/minR
}
```

**Тест:** spawn 36 осколков, перемотать 180 дней → облако должно образовать кольцо (RAAN разошлись), а не оставаться в исходной плоскости.

---

### Этап 2 — Массовое распределение осколков → v2.14
**Файлы:** `js/physics.js`, `js/state.js`, `js/main.js`, `js/scene3d.js`, `index.html`

- Добавить `massToBC(m)` в physics.js (уже описана выше)
- При `explode()` назначать каждому осколку индивидуальную массу по степенному закону (NASA Breakup Model упрощённый): `m_i ∝ (i+1)^(-1.5)`, нормировать на `objMass`
- Каждый осколок хранит `f.mass` и `f.bcoef = massToBC(f.mass)`
- В `rk4()`-вызове передавать `f.bcoef` вместо глобального `BCOEF`
- В `orbitPosAtTime` использовать `f.orb.bcoef`
- Цветовая индикация по массе: крупные — жёлтые/белые, мелкие — голубые/тусклые
- В HUD при выборе осколка: добавить строку «Масса: X кг»
- Слайдер «Масса» в controls теперь означает суммарную массу объекта (как сейчас)

**Тест:** при 500+ км атмосфера выключена → мелкие и крупные осколки орбитируют одинаково (нет тяги). При 300 км атмосфера включена → мелкие (высокое A/m) деорбитируют быстрее.

---

### Этап 3 — Пресеты реальных событий → v2.15
**Файлы:** `index.html`, `js/state.js`, `js/main.js`

Добавить выпадающий список пресетов в панель управления:

| Пресет | Высота | Масса | Δv | Осколки | Примечание |
|---|---|---|---|---|---|
| Custom (текущий) | из полей | из полей | из полей | из полей | |
| Фенчуань-1С (2007) | 865 км | 750 кг | 1200 м/с | 200 | Самое разрушительное |
| Космос 1408 (2021) | 485 км | 2200 кг | 800 м/с | 150 | Российский ASAT-тест |
| Iridium 33 (2009) | 789 км | 560 кг | 600 м/с | 100 | Случайное столкновение |
| Vanguard 1 (500 лет) | 650 км | 1.5 кг | 50 м/с | 10 | Старейший объект |

При выборе пресета — значения подставляются в поля, поля блокируются (readonly). При выборе «Custom» — разблокировать.

**Тест:** выбрать «Фенчуань-1С», запустить, перемотать 1 год → облако равномерно покрывает полярную орбиту (наклонение ~97°). Это невозможно без прецессии RAAN из Этапа 1.

---

### Этап 4 — Экспорт данных → v2.16
**Файлы:** `index.html`, `js/ui.js`

- Кнопка «⬇ CSV» — появляется после взрыва
- Экспортирует: для каждого живого осколка — `id, a_km, e, inc_deg, raan_deg, om_deg, alt_perigee_km, alt_apogee_km, alive, time_days`
- Имя файла: `orbital_debris_T{дней}.csv`
- Реализация: `Blob` + `URL.createObjectURL` + временный `<a>`

---

### Этап 5 — Каскад Кесслера (автоматические столкновения) → v3.0
**Это смена архитектуры → мажорная версия.**

**Концепция:** при перемотке отслеживать сближения осколков (r < COLLISION_RADIUS). При столкновении — порождать дочерние осколки (упрощённо: 2–5 частиц с малым Δv от точки встречи). Показывать счётчик «Столкновений: N».

**Файлы:** `js/physics.js` (функция `checkCollisions`), `js/main.js`, `js/state.js`, `js/scene3d.js`

**Ограничения:**
- Только для skip-time (аналитическая модель позволяет быстро проверить все пары)
- При N>1000 осколков — пространственное разбиение (grid 3D) для O(N) вместо O(N²)
- Порождаемые осколки не порождают новые (глубина 1) — иначе взрывной рост

**Тест:** 200 осколков на 800 км, атмосфера выключена, перемотка 10 лет → должны появиться 5–20 вторичных столкновений.

---

## НЕРЕШЁННЫЕ ВОПРОСЫ

### Прецессия RAAN при реальном времени (не skip)
При RK4 с мелким шагом J2-член корректно даёт прецессию через накопление. Для 36 осколков при скорости 300× симуляция успевает. При 1000+ осколках — возможны тормоза. Решение: **гибридный режим** — при `simSpeed > 1000×` переключаться на аналитику автоматически.

### RAAN из орбитальных элементов
Функция `orbitalElements3D` возвращает `{hx, hy, hz, ex, ey, ez}` — прямого RAAN нет. Вычисление:
```js
const hMag = Math.sqrt(el.hx**2 + el.hy**2 + el.hz**2);
const N = [-el.hy, el.hx, 0]; // вектор узловой линии = Z × h
const Nmag = Math.sqrt(N[0]**2 + N[1]**2);
const Om = Nmag > 1e-10
  ? (N[1] >= 0 ? Math.acos(N[0]/Nmag) : 2*Math.PI - Math.acos(N[0]/Nmag))
  : 0;
```
Это нужно добавить в `orbitalElements3D` или вынести в отдельный хелпер.

### Начальная средняя аномалия M0
При spawn осколка нужно вычислить `M0` из текущей позиции. Через решение Кеплерова уравнения в обратную сторону или через эксцентрическую аномалию:
```js
const E0 = 2 * Math.atan2(Math.sqrt(1-e)*Math.sin(nu/2), Math.sqrt(1+e)*Math.cos(nu/2));
const M0 = E0 - e * Math.sin(E0);
```
где `nu` — истинная аномалия, получаемая из вектора эксцентриситета и позиции.
