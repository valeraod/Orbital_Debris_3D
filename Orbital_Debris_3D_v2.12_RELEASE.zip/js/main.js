// ══════════════════════════════════════════════════════════════════════════════
// MAIN — physics helpers (stepMainObj, stepFrags, explode, ...),
//        render/sim loop, инициализация
// Загружается ПОСЛЕДНИМ — после state.js, physics.js, scene3d/2d, ui, input.
// Classic script — все объявления глобальные.
// ══════════════════════════════════════════════════════════════════════════════

function mainPos(t){
  const th=2*Math.PI*t/T0;
  return[RORB*Math.cos(th),0,RORB*Math.sin(th)];
}
function mainVel(t){
  const th=2*Math.PI*t/T0;
  return[-V0*Math.sin(th),0,V0*Math.cos(th)];
}

function initMainObj(){
  const[x,y,z]=mainPos(simTime);
  const[vx,vy,vz]=mainVel(simTime);
  const vMag=Math.sqrt(vx*vx+vy*vy+vz*vz);
  const scale=(vMag+launchDv)/vMag;
  const mvx=vx*scale,mvy=vy*scale,mvz=vz*scale;
  const r0=Math.sqrt(x*x+y*y+z*z);
  const e0=(mvx*mvx+mvy*mvy+mvz*mvz)/2-GM/r0;
  mainObj={x,y,z,vx:mvx,vy:mvy,vz:mvz,alive:true,
    trail:new Float32Array(TRAIL_LEN*3),
    trailHead:0,trailLen:0,_lastTrailColor:-1,
    maxR:RORB,minR:RORB,_e0:e0};
}

function adaptiveSkipDt(){
  if(!exploded||frags.length===0)return 60;
  let minR=Infinity;
  for(const f of frags){
    if(!f.alive)continue;
    const r=Math.sqrt(f.x*f.x+f.y*f.y+f.z*f.z);
    if(r<minR)minR=r;
  }
  const h=(minR-RE)/1e3;
  if(h<200)return 2;
  if(h<300)return 5;
  if(h<400)return 20;
  return 60;
}

function correctFragEnergies(){
  if(atmoEnabled)return;
  if(mainObj&&mainObj.alive&&!exploded&&mainObj._e0!==undefined){
    const r=Math.sqrt(mainObj.x*mainObj.x+mainObj.y*mainObj.y+mainObj.z*mainObj.z);
    if(isFinite(r)&&r>RE){
      const v2=mainObj.vx*mainObj.vx+mainObj.vy*mainObj.vy+mainObj.vz*mainObj.vz;
      const currentE=v2/2-GM/r;
      if(currentE<0){
        const vTarget2=2*(mainObj._e0+GM/r);
        if(vTarget2>0){const sc=Math.sqrt(vTarget2/v2);mainObj.vx*=sc;mainObj.vy*=sc;mainObj.vz*=sc;}
      }
    }
  }
  for(const f of frags){
    if(!f.alive||f.beyond||f._e0===undefined)continue;
    const r=Math.sqrt(f.x*f.x+f.y*f.y+f.z*f.z);
    if(!isFinite(r)||r<=RE)continue;
    const v2=f.vx*f.vx+f.vy*f.vy+f.vz*f.vz;
    const currentE=v2/2-GM/r;
    if(currentE>=0)continue;
    const vTarget2=2*(f._e0+GM/r);
    if(vTarget2<=0)continue;
    const scale=Math.sqrt(vTarget2/v2);
    f.vx*=scale;f.vy*=scale;f.vz*=scale;
  }
}

function stepMainObj(dt){
  if(!mainObj||!mainObj.alive||exploded)return;
  const r0=Math.sqrt(mainObj.x**2+mainObj.y**2+mainObj.z**2);
  const nsub=adaptiveSubs(dt,r0);
  const dts=dt/nsub;
  let{x,y,z,vx,vy,vz}=mainObj;
  for(let s=0;s<nsub;s++){
    const r=Math.sqrt(x*x+y*y+z*z);
    if(r<RE){mainObj.alive=false;mainObj.escaped=false;document.getElementById('bBoom').disabled=true;break;}
    if(r>R_OBS){mainObj.alive=false;mainObj.escaped=true;document.getElementById('bBoom').disabled=true;break;}
    rk4(x,y,z,vx,vy,vz,dts,true,_rk4out,atmoEnabled,BCOEF);
    if(!isFinite(_rk4out[0])||!isFinite(_rk4out[1])||!isFinite(_rk4out[2])){mainObj.alive=false;document.getElementById('bBoom').disabled=true;break;}
    x=_rk4out[0];y=_rk4out[1];z=_rk4out[2];
    vx=_rk4out[3];vy=_rk4out[4];vz=_rk4out[5];
  }
  if(mainObj.alive){
    if(!fastForward){
      const base=mainObj.trailHead*3;
      mainObj.trail[base]=mainObj.x;mainObj.trail[base+1]=mainObj.y;mainObj.trail[base+2]=mainObj.z;
      mainObj.trailHead=(mainObj.trailHead+1)%TRAIL_LEN;
      if(mainObj.trailLen<TRAIL_LEN)mainObj.trailLen++;
    }
    mainObj.x=x;mainObj.y=y;mainObj.z=z;
    mainObj.vx=vx;mainObj.vy=vy;mainObj.vz=vz;
    const r=Math.sqrt(x*x+y*y+z*z);
    if(r>mainObj.maxR&&r<R_OBS)mainObj.maxR=r;
    if(r<mainObj.minR)mainObj.minR=r;
  }
}

function stepFrags(dt){
  for(const f of frags){
    if(!f.alive)continue;
    let x=f.x,y=f.y,z=f.z,vx=f.vx,vy=f.vy,vz=f.vz;
    const r0=Math.sqrt(x*x+y*y+z*z);
    const nsub=adaptiveSubs(dt,r0);
    const dts=dt/nsub;
    for(let s=0;s<nsub;s++){
      const r=Math.sqrt(x*x+y*y+z*z);
      if(r<RE){f.alive=false;f.escaped=false;aliveCount--;break;}
      if(r>R_OBS){
        const v2=vx*vx+vy*vy+vz*vz;
        if(v2/2-GM/r>=0){f.alive=false;f.escaped=true;aliveCount--;break;}
        break;
      }
      rk4(x,y,z,vx,vy,vz,dts,true,_rk4out,atmoEnabled,BCOEF);
      if(!isFinite(_rk4out[0])||!isFinite(_rk4out[1])||!isFinite(_rk4out[2])){f.alive=false;aliveCount--;break;}
      x=_rk4out[0];y=_rk4out[1];z=_rk4out[2];
      vx=_rk4out[3];vy=_rk4out[4];vz=_rk4out[5];
    }
    if(f.alive){
      const r=Math.sqrt(x*x+y*y+z*z);
      f.beyond=(r>R_OBS);
      if(!f.beyond){
        if(!fastForward){
          const base=f.trailHead*3;
          f.trail[base]=f.x;f.trail[base+1]=f.y;f.trail[base+2]=f.z;
          f.trailHead=(f.trailHead+1)%TRAIL_LEN;
          if(f.trailLen<TRAIL_LEN)f.trailLen++;
        }
        if(isFinite(r)&&r>f.maxR)f.maxR=r;
        if(isFinite(r)&&r<f.minR)f.minR=r;
      }
      f.x=x;f.y=y;f.z=z;f.vx=vx;f.vy=vy;f.vz=vz;
    }
  }
}

function explode(){
  exploded=true; explodeTime=simTime;
  document.getElementById('bBoom').disabled=true;
  document.getElementById('stats-panel').classList.add('visible');
  const[x0,y0,z0]=mainObj&&mainObj.alive?[mainObj.x,mainObj.y,mainObj.z]:mainPos(simTime);
  const[vx0,vy0,vz0]=mainObj&&mainObj.alive?[mainObj.vx,mainObj.vy,mainObj.vz]:mainVel(simTime);
  freezeMainOrbit();
  freezeMainOrbit2D();
  frags=[];aliveCount=0;
  const rng=mulberry32(Date.now()|0);
  const dvDist=document.getElementById('selDvDist').value;
  for(let i=0;i<NFRAG;i++){
    const u=rng()*2-1;
    const phi=rng()*Math.PI*2;
    const sinPhi=Math.sqrt(1-u*u);
    let dv;
    if(dvDist==='exponential'){
      dv=dvMag*(-Math.log(Math.max(1e-10,rng())));
      dv=Math.min(dv,dvMag*5);
    } else if(dvDist==='maxwell'){
      const sig=dvMag/Math.sqrt(3);
      const g1=(Math.sqrt(-2*Math.log(Math.max(1e-10,rng())))*Math.cos(rng()*2*Math.PI))*sig;
      const g2=(Math.sqrt(-2*Math.log(Math.max(1e-10,rng())))*Math.cos(rng()*2*Math.PI))*sig;
      const g3=(Math.sqrt(-2*Math.log(Math.max(1e-10,rng())))*Math.cos(rng()*2*Math.PI))*sig;
      dv=Math.sqrt(g1*g1+g2*g2+g3*g3);
    } else {
      dv=dvMag*(NFRAG>36?(0.8+rng()*0.4):1.0);
    }
    const fvx=vx0+dv*sinPhi*Math.cos(phi);
    const fvy=vy0+dv*u;
    const fvz=vz0+dv*sinPhi*Math.sin(phi);
    const fr0=Math.sqrt(x0*x0+y0*y0+z0*z0);
    const fe0=(fvx*fvx+fvy*fvy+fvz*fvz)/2-GM/fr0;
    frags.push({
      x:x0,y:y0,z:z0,
      vx:fvx,vy:fvy,vz:fvz,
      hue:15+(i/NFRAG)*60,alive:true,beyond:false,escaped:false,
      trail:new Float32Array(TRAIL_LEN*3),
      trailHead:0,trailLen:0,_lastTrailColor:-1,
      maxR:RORB,minR:RORB,_e0:fe0,
    });
    aliveCount++;
  }
  build3DFragMeshes();
  build3DTrailLines();
  updateStats();
}

// ── Render / Sim loop ─────────────────────────────────────────────────────────
function render(){
  if(is2D) render2D();
  else render3D();
}

function loop(){
  if(!running)return;
  const now=performance.now();
  let dt=lastTs!==null?(now-lastTs)/1000*simSpeed:0;
  lastTs=now;
  if(exploded){
    const subDt=dt/SUB_STEPS;
    for(let i=0;i<SUB_STEPS;i++)stepFrags(subDt);
    updateStats();
  } else {
    const subDt=dt/SUB_STEPS;
    for(let i=0;i<SUB_STEPS;i++)stepMainObj(subDt);
    if(pendingExplode){pendingExplode=false;explode();}
  }
  simTime+=dt;
  requestAnimationFrame(render);
  rafId=setTimeout(loop,SIM_INTERVAL);
}

function idleRender(){
  requestAnimationFrame(idleRender);
  if(!running)render();
}

// ── Init ──────────────────────────────────────────────────────────────────────
window.addEventListener('resize',()=>{
  resize3D();
  if(is2D)resize2D();
});

buildStars2();
initMainObj();
requestAnimationFrame(idleRender);
setTimeout(()=>{
  resize3D();
  resize2D();
  simSpeed=+document.getElementById('sSpd').value;
},50);
