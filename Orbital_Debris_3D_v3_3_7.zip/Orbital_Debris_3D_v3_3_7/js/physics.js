// ══════════════════════════════════════════════════════════════════════════════
// PHYSICS — pure functions shared between 3D and 2D renderers // ── [v2.13.1]
// No DOM access, no shared mutable state — all inputs are parameters.
// Classic script (no ES modules) — declarations become global.
// ══════════════════════════════════════════════════════════════════════════════

const GM    = 3.986e14;
const RE    = 6371e3;
const J2    = 1.08263e-3;
const R_OBS = 4e8; // Граница наблюдений: 400 000 км
const CD    = 2.2;   // drag coefficient (sphere)
const AREA  = 0.45;  // cross-section area, m² (≈ 75 cm diameter sphere)

const ATMO_LAYERS = [
  [0,1.225,8500],[11e3,0.3639,6341],[25e3,0.04008,6381],
  [47e3,0.001846,7922],[86e3,5.457e-6,5900],[100e3,5.6e-7,15000],
  [120e3,2.438e-8,11500],[200e3,2.541e-10,8300],[300e3,1.916e-11,9000],
  [400e3,2.803e-12,10000],[500e3,5.215e-13,11000],[600e3,1.137e-13,12000],
  [700e3,3.070e-14,14000],[1000e3,3.019e-15,160000],
];

function airDensity(h){
  if(h>=1500e3)return 0;
  let layer=ATMO_LAYERS[0];
  for(let i=ATMO_LAYERS.length-1;i>=0;i--){if(h>=ATMO_LAYERS[i][0]){layer=ATMO_LAYERS[i];break;}}
  return layer[1]*Math.exp(-(h-layer[0])/layer[2]);
}

const _k=new Float64Array(24);
// rk4: atmoEnabled и BCOEF переданы как параметры (в оригинале — глобальные переменные)
function rk4(x,y,z,vx,vy,vz,dt,drag,out,atmoEnabled,BCOEF){
  function derivInto(ox,oy,oz,ovx,ovy,ovz,base){
    const r=Math.sqrt(ox*ox+oy*oy+oz*oz);
    const r2=r*r, r5=r2*r2*r;
    const ag=-GM/r2;
    const j2f=1.5*J2*GM*RE*RE/r5;
    const yr2=oy*oy/r2;
    let ax=ag*ox/r+j2f*ox*(1-5*yr2);
    let ay=ag*oy/r+j2f*oy*(3-5*yr2);
    let az=ag*oz/r+j2f*oz*(1-5*yr2);
    if(drag&&atmoEnabled){
      const rho=airDensity(r-RE);
      const v=Math.sqrt(ovx*ovx+ovy*ovy+ovz*ovz);
      const ad=rho*v/(2*BCOEF);
      ax-=ad*ovx; ay-=ad*ovy; az-=ad*ovz;
    }
    _k[base]=ovx;_k[base+1]=ovy;_k[base+2]=ovz;
    _k[base+3]=ax;_k[base+4]=ay;_k[base+5]=az;
  }
  const h=dt/2;
  derivInto(x,y,z,vx,vy,vz,0);
  derivInto(x+_k[0]*h,y+_k[1]*h,z+_k[2]*h,vx+_k[3]*h,vy+_k[4]*h,vz+_k[5]*h,6);
  derivInto(x+_k[6]*h,y+_k[7]*h,z+_k[8]*h,vx+_k[9]*h,vy+_k[10]*h,vz+_k[11]*h,12);
  derivInto(x+_k[12]*dt,y+_k[13]*dt,z+_k[14]*dt,vx+_k[15]*dt,vy+_k[16]*dt,vz+_k[17]*dt,18);
  const s=dt/6;
  out[0]=x+(_k[0]+2*_k[6]+2*_k[12]+_k[18])*s;
  out[1]=y+(_k[1]+2*_k[7]+2*_k[13]+_k[19])*s;
  out[2]=z+(_k[2]+2*_k[8]+2*_k[14]+_k[20])*s;
  out[3]=vx+(_k[3]+2*_k[9]+2*_k[15]+_k[21])*s;
  out[4]=vy+(_k[4]+2*_k[10]+2*_k[16]+_k[22])*s;
  out[5]=vz+(_k[5]+2*_k[11]+2*_k[17]+_k[23])*s;
}

function orbitalElements3D(x,y,z,vx,vy,vz){
  const r=Math.sqrt(x*x+y*y+z*z);
  const v2=vx*vx+vy*vy+vz*vz;
  const eps=v2/2-GM/r;
  const hyperbolic=eps>=0;
  const a=hyperbolic?GM/(2*eps):-GM/(2*eps);
  const hx=y*vz-z*vy,hy=z*vx-x*vz,hz=x*vy-y*vx;
  const hMag=Math.sqrt(hx*hx+hy*hy+hz*hz);
  const rdotv=(x*vx+y*vy+z*vz);
  const ex=(v2/GM-1/r)*x-rdotv/GM*vx;
  const ey=(v2/GM-1/r)*y-rdotv/GM*vy;
  const ez=(v2/GM-1/r)*z-rdotv/GM*vz;
  const e=Math.sqrt(ex*ex+ey*ey+ez*ez);
  const rp=hyperbolic?a*(e-1):a*(1-e);
  const ra=hyperbolic?Infinity:a*(1+e);
  const inc=Math.acos(Math.max(-1,Math.min(1,hz/hMag)))*180/Math.PI;
  // RAAN (Ω) — угол восходящего узла
  const Nx=-hy, Ny=hx; // вектор узловой линии N = Z × h = (-hy, hx, 0)
  const Nmag=Math.sqrt(Nx*Nx+Ny*Ny);
  const Om=Nmag>1e-10
    ?(Ny>=0?Math.acos(Nx/Nmag):2*Math.PI-Math.acos(Nx/Nmag))
    :0;
  // Аргумент перигея (ω)
  // [v3.2.6-fix] БЫЛО: om_raw=atan2(ez*Nmag, Nx*ex+Ny*ey) — неполная формула,
  // у синусной части не хватало слагаемого. При hz≈0 (наклонение основной
  // орбиты ≈0°) ошибка не проявлялась, при ненулевом наклонении давала
  // систематическую ошибку om до ~58°. Заменено на ту же конструкцию
  // (acos + ручная коррекция знака через ez), что верифицирована в
  // density_cloud.js дочернего проекта star-destroyer — там этого бага нет.
  // Здесь это критично для f.orb, сохраняемого на каждый осколок и
  // используемого в orbitPosAtTime() при перемотке времени
  // (bSkip/«Перемотать») — без фикса позиции осколков после перемотки
  // были бы искажены на наклонённых орбитах, хотя в реал-тайме (через RK4)
  // всё было верно.
  const eMag=e;
  let om=0;
  if(eMag>1e-8&&Nmag>1e-6){
    const eNdot=(Nx*ex+Ny*ey)/(Nmag*eMag);
    om=Math.acos(Math.max(-1,Math.min(1,eNdot)));
    if(ez<0) om=2*Math.PI-om;
  }
  // Истинная аномалия (ν) и средняя аномалия M0
  const cosNu=(ex*x+ey*y+ez*z)/(eMag*r+1e-30);
  const nu_raw=Math.acos(Math.max(-1,Math.min(1,cosNu)));
  const nu=rdotv>=0?nu_raw:2*Math.PI-nu_raw;
  const E0=2*Math.atan2(Math.sqrt(Math.max(0,1-eMag))*Math.sin(nu/2),Math.sqrt(1+eMag)*Math.cos(nu/2));
  const M0=((E0-eMag*Math.sin(E0))+2*Math.PI)%(2*Math.PI);
  const incRad=Math.acos(Math.max(-1,Math.min(1,hz/hMag)));
  return{a,e,rp,ra,inc,hx,hy,hz,ex,ey,ez,hyperbolic,Om,om,M0,nu,incRad};
}

function orbitalElements2D(x,y,z,vx,vy,vz){
  // Use full 3D elements for accuracy (vy included — handles inclined orbits correctly)
  const el=orbitalElements3D(x,y,z,vx,vy,vz);
  if(!el)return null;
  const{a,e,rp,ra,ex,ey,ez,hyperbolic}=el;
  // Project eccentricity vector onto XZ plane to get screen orientation angle
  const omega=Math.atan2(ez,ex);
  return{a,e,rp,ra,omega,hyperbolic};
}

function mulberry32(seed){
  return function(){
    seed|=0;seed=seed+0x6D2B79F5|0;
    let t=Math.imul(seed^seed>>>15,1|seed);
    t=t+Math.imul(t^t>>>7,61|t)^t;
    return((t^t>>>14)>>>0)/4294967296;
  };
}

function adaptiveSubs(dt,r){
  const h=r-RE;
  const maxDt=h<200e3?2:h<300e3?10:60;
  return Math.max(6,Math.ceil(dt/maxDt));
}

// ── Аналитическая орбитальная модель с J2-прецессией ─────────────────────────

// Кеплерово уравнение — метод Ньютона (8 итераций, точность 1e-10)
function solveKepler(M,e){
  let E=M;
  for(let k=0;k<8;k++){
    const dE=(M-(E-e*Math.sin(E)))/(1-e*Math.cos(E));
    E+=dE;
    if(Math.abs(dE)<1e-10)break;
  }
  return E;
}

// Аналитическое распространение орбиты с J2-прецессией RAAN и аргумента перигея.
// orb: { a, e, incRad, Om, om, M0, spawnT, bcoef }
// t: текущее время симуляции (сек), atmoOn: bool
// Возвращает {x,y,z} в ECI (Z-up) или null (деорбитировал / гиперболическая)
function orbitPosAtTime(orb,t,atmoOn){
  let{a,e,incRad:i,Om,om,M0,spawnT,bcoef}=orb;
  if(a<=0||e>=1)return null;
  const dt=t-spawnT;
  if(dt<0)return null;

  // Упрощённое атмосферное торможение через плотность у перигея
  if(atmoOn&&bcoef>0){
    const rp0=a*(1-e);
    const rho_p=airDensity(rp0-RE);
    const v_orb=Math.sqrt(GM/a);
    const da=-(rho_p*v_orb*a/bcoef)*dt;
    const a2=a+da;
    if(a2<=RE+50e3)return null;
    e=Math.max(0,e*(a2/a));
    a=a2;
  }
  const rp=a*(1-e);
  if(rp<RE+50e3)return null;

  // Средняя аномалия
  const n=Math.sqrt(GM/(a*a*a));
  const TWO_PI=2*Math.PI;
  const M=((M0+n*dt)%TWO_PI+TWO_PI)%TWO_PI;

  // J2-прецессия RAAN (Ω) и аргумента перигея (ω)
  const cosI=Math.cos(i);
  const sinI=Math.sin(i);
  const p=a*(1-e*e);
  const j2rate=1.5*n*J2*(RE/p)*(RE/p);
  const dOm=-j2rate*cosI*dt;
  const dom= j2rate*(2.5*sinI*sinI-2)*dt;
  const Om2=Om+dOm;
  const om2=om+dom;

  // Позиция в орбитальной плоскости
  const E=solveKepler(M,e);
  const nu=2*Math.atan2(Math.sqrt(1+e)*Math.sin(E/2),Math.sqrt(Math.max(0,1-e))*Math.cos(E/2));
  const r=a*(1-e*Math.cos(E));
  const xOrb=r*Math.cos(nu),yOrb=r*Math.sin(nu);

  // Матрица Гаусса → ECI (Z-up)
  const cosOm=Math.cos(Om2),sinOm=Math.sin(Om2);
  const cosi=Math.cos(i),sini=Math.sin(i);
  const coso=Math.cos(om2),sino=Math.sin(om2);
  const Px= cosOm*coso-sinOm*sino*cosi;
  const Py= sinOm*coso+cosOm*sino*cosi;
  const Pz= sino*sini;
  const Qx=-cosOm*sino-sinOm*coso*cosi;
  const Qy=-sinOm*sino+cosOm*coso*cosi;
  const Qz= coso*sini;
  // Скорость в орбитальной плоскости
  const h_mag=Math.sqrt(GM*a*(1-e*e));
  const sinNu=Math.sin(nu),cosNu=Math.cos(nu);
  const vxOrb=-GM/h_mag*sinNu;
  const vyOrb= GM/h_mag*(e+cosNu);
  return{
    x:xOrb*Px+yOrb*Qx,
    y:xOrb*Py+yOrb*Qy,
    z:xOrb*Pz+yOrb*Qz,
    vx:vxOrb*Px+vyOrb*Qx,
    vy:vxOrb*Py+vyOrb*Qy,
    vz:vxOrb*Pz+vyOrb*Qz,
  };
}

// Баллистический коэффициент из массы (сфера, ср. плотность 200 кг/м³, CD=2.2)
function massToBC(m){
  const r_sphere=Math.pow(m/(200*(4/3)*Math.PI),1/3);
  const area=Math.PI*r_sphere*r_sphere;
  return m/(CD*Math.max(area,0.001));
}

// ── [v3.2.8] Шаг 1 REFACTOR_PLAN_v3.2.md: сэмплирование орбиты ──────────────
// Идентичная математика (точки эллипса по эксцентрической аномалии E, точки
// гиперболы по истинной аномалии nu, в локальных координатах орбитальной
// плоскости — ДО поворота базисом P/Q в ECI для 3D или поворота на экране
// для 2D) была продублирована в 7 местах между scene3d.js и scene2d.js.
// segs и nuMaxCoef ОСТАЮТСЯ параметрами (не унифицированы) — расхождения
// между копиями условные, а не случайные, см. таблицу в плане:
//   3D "одна линия" (live/выбранный осколок/все-орбиты-разом): segs=128,
//     nuMaxCoef=0.98. 3D frozen (пунктир): segs=96.
//   2D одна линия: segs=80, nuMaxCoef=0.97. 2D все-орбиты-разом: segs=64.
// Эллиптическая ветка в 2D вообще НЕ вызывает эту функцию — рисуется через
// нативный ctx2.ellipse(), идеально гладкий примитив Canvas2D без полилинии.
// sampleOrbitLocal() в 2D используется ТОЛЬКО для гиперболической ветки.
//
// Проверки a>1e9 (почти-параболическая орбита, не рисуем) и rMaxEllipse
// (отсечка слишком далёких точек на эллиптической ветке) раньше были не
// везде одинаковы — конкретно updateSelOrbit3D() в scene3d.js не имела ни
// одной из них, в отличие от buildMainOrbitLine()/buildAllOrbitLines3D().
// Решено (обсуждено с Валерием): это недосмотр, не намеренное расхождение —
// обе проверки теперь применяются единообразно везде через эту функцию.
//
// el: результат orbitalElements3D() — нужны a, e, hyperbolic.
// segs: число сегментов, передаётся каждым вызывающим кодом индивидуально.
// nuMaxCoef: коэффициент запаса от асимптоты гиперболы (0.97 в 2D, 0.98 в 3D).
// rMaxHyperbola: точка отсечения по радиусу на гиперболической ветке (везде RE*60).
// rMaxEllipse: точка отсечения по радиусу на эллиптической ветке (везде R_OBS).
// Возвращает массив длины segs+1 — точки {x,y} в локальных координатах
// орбитальной плоскости, либо null на месте точки, которая не прошла
// проверку (r не finite / r<0 / r>rMax). Длина массива ВСЕГДА равна segs+1
// (не короче) — это важно для 2D-адаптера: он использует null как сигнал
// "здесь разрыв, начать новый moveTo", в точности как делал прежний инлайн-код
// с флагом first/continue. Если орбита не рисуется вовсе (a<=0 — проверяется
// вызывающим кодом до вызова; a>1e9 — проверяется здесь), возвращает [].
function sampleOrbitLocal(el, segs, nuMaxCoef, rMaxHyperbola, rMaxEllipse){
  const{a,e,hyperbolic}=el;
  const pts=[];
  if(hyperbolic){
    const nuMax=Math.acos(-1/e)*nuMaxCoef;
    for(let i=0;i<=segs;i++){
      const nu=-nuMax+i/segs*2*nuMax;
      const r=a*(e*e-1)/(1+e*Math.cos(nu));
      if(!isFinite(r)||r<0||r>rMaxHyperbola){pts.push(null);continue;}
      pts.push({x:r*Math.cos(nu),y:r*Math.sin(nu)});
    }
  } else {
    if(a>1e9)return [];
    for(let i=0;i<=segs;i++){
      const E=i/segs*Math.PI*2;
      const nu=2*Math.atan2(Math.sqrt(1+e)*Math.sin(E/2),Math.sqrt(1-e)*Math.cos(E/2));
      const r=a*(1-e*e)/(1+e*Math.cos(nu));
      if(!isFinite(r)||r>rMaxEllipse){pts.push(null);continue;}
      pts.push({x:r*Math.cos(nu),y:r*Math.sin(nu)});
    }
  }
  return pts;
}
