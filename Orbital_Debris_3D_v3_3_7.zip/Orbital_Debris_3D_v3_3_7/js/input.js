// ══════════════════════════════════════════════════════════════════════════════
// INPUT — обработчики мыши и тача // ── [v3.0.6] для canvas3 (3D) и canvas2 (2D), pickFrag3D
// Classic script (no ES modules) — declarations are global.
// Зависит от: scene3d.js (canvas3, camera, raycaster, hitTestEarth, applyPan,
//   camDist, camTheta, camPhi, camTargetX/Y/Z, updateCamera, scene, mainMesh,
//   fragMeshes, selOrbitLine, updateSelOrbit3D, objSizePx),
// scene2d.js (canvas2, zoom2, camX2, camY2, S2, ocx2, ocy2, pickFrag2D),
// ui.js (updateFragInfo, updateFocusBtn, setFocusMode).
// Переменные состояния (is2D, frags, mainObj, exploded, selectedFrag, selectedMain,
// focusMode) — глобальные из index.html.
// ══════════════════════════════════════════════════════════════════════════════
let drag2=false, drag2StartX=0, drag2StartY=0, cam2StartX=0, cam2StartY=0;
let pinch2Dist0=null, pinch2Zoom0=null, pinch2MidX=0, pinch2MidY=0, touch2CamX0=0, touch2CamY0=0;
let touch2DragX=0, touch2DragY=0;

// ── 2D input events ───────────────────────────────────────────────────────────
let mouseMoved2=false, mouseDown2X=0, mouseDown2Y=0;

canvas2.addEventListener('mousedown', e=>{
  drag2=true;
  drag2StartX=e.clientX; drag2StartY=e.clientY;
  cam2StartX=camX2; cam2StartY=camY2;
  mouseDown2X=e.clientX; mouseDown2Y=e.clientY;
  mouseMoved2=false;
  canvas2.style.cursor='grabbing';
});
window.addEventListener('mousemove', e=>{
  if(!drag2||!is2D)return;
  if(Math.abs(e.clientX-mouseDown2X)>4||Math.abs(e.clientY-mouseDown2Y)>4)mouseMoved2=true;
  camX2=cam2StartX+(e.clientX-drag2StartX);
  camY2=cam2StartY+(e.clientY-drag2StartY);
});
window.addEventListener('mouseup', e=>{
  if(is2D){
    if(!mouseMoved2&&e.target===canvas2)pickFrag2D(e.clientX, e.clientY);
    canvas2.style.cursor='default';
  }
  drag2=false;
});
canvas2.addEventListener('wheel', e=>{
  e.preventDefault();
  const factor=e.deltaY<0?1.15:1/1.15;
  const rect=canvas2.getBoundingClientRect();
  const mx=e.clientX-rect.left, my=e.clientY-rect.top;
  const dx=mx-ocx2(), dy=my-ocy2();
  camX2+=dx*(1-factor);
  camY2+=dy*(1-factor);
  zoom2=Math.max(0.04,Math.min(20,zoom2*factor));
},{passive:false});

canvas2.addEventListener('touchstart', e=>{
  e.preventDefault();
  const ts=Array.from(e.touches);
  if(ts.length===1){
    touch2DragX=ts[0].clientX; touch2DragY=ts[0].clientY;
    touch2CamX0=camX2; touch2CamY0=camY2;
    pinch2Dist0=null;
  } else if(ts.length===2){
    pinch2Dist0=Math.hypot(ts[0].clientX-ts[1].clientX,ts[0].clientY-ts[1].clientY);
    pinch2Zoom0=zoom2;
    const rect=canvas2.getBoundingClientRect();
    pinch2MidX=((ts[0].clientX+ts[1].clientX)/2)-rect.left;
    pinch2MidY=((ts[0].clientY+ts[1].clientY)/2)-rect.top;
    touch2CamX0=camX2; touch2CamY0=camY2;
  }
},{passive:false});
canvas2.addEventListener('touchmove', e=>{
  e.preventDefault();
  const ts=Array.from(e.touches);
  if(ts.length===1&&pinch2Dist0===null){
    camX2=touch2CamX0+(ts[0].clientX-touch2DragX);
    camY2=touch2CamY0+(ts[0].clientY-touch2DragY);
  } else if(ts.length===2&&pinch2Dist0!==null){
    const dist=Math.hypot(ts[0].clientX-ts[1].clientX,ts[0].clientY-ts[1].clientY);
    const factor=dist/pinch2Dist0;
    const newZoom=Math.max(0.04,Math.min(20,pinch2Zoom0*factor));
    const dx=pinch2MidX-ocx2(), dy=pinch2MidY-ocy2();
    camX2=touch2CamX0+dx*(1-newZoom/pinch2Zoom0);
    camY2=touch2CamY0+dy*(1-newZoom/pinch2Zoom0);
    zoom2=newZoom;
  }
},{passive:false});
canvas2.addEventListener('touchend', e=>{
  if(e.touches.length<2)pinch2Dist0=null;
  if(e.touches.length===1){touch2DragX=e.touches[0].clientX;touch2DragY=e.touches[0].clientY;}
  if(e.changedTouches.length===1)pickFrag2D(e.changedTouches[0].clientX,e.changedTouches[0].clientY);
},{passive:true});

// ── 3D input events ───────────────────────────────────────────────────────────
canvas3.addEventListener('mousedown', e=>{
  if(e.button!==0)return;
  dragActive=true; dragBtn=e.button;
  lastMX=e.clientX; lastMY=e.clientY;
  mouseDownX=e.clientX; mouseDownY=e.clientY;
  mouseMoved=false;
  // клик по планете — вращение, рядом — панорама (как в Star Destroyer)
  dragMode=hitTestEarth(e.clientX,e.clientY)?'orbit':'pan';
});
canvas3.addEventListener('contextmenu', e=>e.preventDefault());
window.addEventListener('mousemove', e=>{
  if(!dragActive||is2D)return;
  const dx=e.clientX-lastMX, dy=e.clientY-lastMY;
  if(Math.abs(e.clientX-mouseDownX)>4||Math.abs(e.clientY-mouseDownY)>4)mouseMoved=true;
  lastMX=e.clientX; lastMY=e.clientY;
  if(dragMode==='orbit'){
    camTheta-=dx*0.005;
    camPhi=Math.max(0.05,Math.min(Math.PI-0.05,camPhi+dy*0.005));
  } else {
    applyPan(dx,dy);
  }
  updateCamera();
});
window.addEventListener('mouseup', e=>{
  if(!is2D&&!mouseMoved&&e.target===canvas3)pickFrag3D(e.clientX, e.clientY);
  dragActive=false;
});
canvas3.addEventListener('wheel', e=>{
  e.preventDefault();
  window._camUserZoomed=true;
  camDist=Math.max(RE*1.1,Math.min(RE*200,camDist*(e.deltaY>0?1.12:1/1.12)));
  updateCamera();
},{passive:false});

let touches3={};
let pinchDist0=null, pinchCamDist0=0;
let touchDragLast={x:0,y:0};
let touchMoved3=false, touchDown3X=0, touchDown3Y=0;
canvas3.addEventListener('touchstart', e=>{
  e.preventDefault();
  const ts=Array.from(e.touches);
  if(ts.length===1){
    touchDragLast={x:ts[0].clientX,y:ts[0].clientY};
    touchDown3X=ts[0].clientX; touchDown3Y=ts[0].clientY;
    touchMoved3=false;
    pinchDist0=null;
    // тап по планете — вращение, рядом — панорама (как у мыши)
    dragMode=hitTestEarth(ts[0].clientX,ts[0].clientY)?'orbit':'pan';
  } else if(ts.length===2){
    const dx=ts[0].clientX-ts[1].clientX, dy=ts[0].clientY-ts[1].clientY;
    pinchDist0=Math.sqrt(dx*dx+dy*dy);
    pinchCamDist0=camDist;
  }
},{passive:false});
canvas3.addEventListener('touchmove', e=>{
  e.preventDefault();
  const ts=Array.from(e.touches);
  if(ts.length===1&&pinchDist0===null){
    const dx=ts[0].clientX-touchDragLast.x, dy=ts[0].clientY-touchDragLast.y;
    if(Math.abs(ts[0].clientX-touchDown3X)>4||Math.abs(ts[0].clientY-touchDown3Y)>4)touchMoved3=true;
    touchDragLast={x:ts[0].clientX,y:ts[0].clientY};
    if(dragMode==='orbit'){
      camTheta-=dx*0.005;
      camPhi=Math.max(0.05,Math.min(Math.PI-0.05,camPhi+dy*0.005));
    } else {
      applyPan(dx,dy);
    }
    updateCamera();
  } else if(ts.length===2&&pinchDist0!==null){
    const dx=ts[0].clientX-ts[1].clientX, dy=ts[0].clientY-ts[1].clientY;
    const d=Math.sqrt(dx*dx+dy*dy);
    window._camUserZoomed=true;
    camDist=Math.max(RE*1.1,Math.min(RE*200,pinchCamDist0*(pinchDist0/d)));
    updateCamera();
  }
},{passive:false});
canvas3.addEventListener('touchend', e=>{
  if(e.touches.length<2)pinchDist0=null;
  if(e.touches.length===1)touchDragLast={x:e.touches[0].clientX,y:e.touches[0].clientY};
  if(e.changedTouches.length===1&&!touchMoved3){
    pickFrag3D(e.changedTouches[0].clientX,e.changedTouches[0].clientY);
  }
},{passive:false});

function pickFrag3D(clientX, clientY){
  const rect=canvas3.getBoundingClientRect();
  const mouse=new THREE.Vector2(
    ((clientX-rect.left)/rect.width)*2-1,
    -((clientY-rect.top)/rect.height)*2+1
  );
  raycaster.setFromCamera(mouse,activeCamera3D());
  // check frags
  const hits=raycaster.intersectObjects(fragMeshes);
  if(hits.length>0){
    const idx=fragMeshes.indexOf(hits[0].object);
    selectedFrag=(selectedFrag===idx)?null:idx; selectedMain=false;
    if(selectedFrag!==null) updateSelOrbit3D();
    else if(selOrbitLine){scene.remove(selOrbitLine);selOrbitLine=null;}
  } else {
    // check mainObj
    const mainHits=mainObj&&mainObj.alive&&!exploded?raycaster.intersectObject(mainMesh):[];
    if(mainHits.length>0){
      selectedMain=!selectedMain; selectedFrag=null;
      if(selOrbitLine){scene.remove(selOrbitLine);selOrbitLine=null;}
    } else {
      selectedFrag=null; selectedMain=false;
      if(selOrbitLine){scene.remove(selOrbitLine);selOrbitLine=null;}
    }
  }
  updateFragInfo();
  updateFocusBtn();
}

