// ── [v3.1.2] density_cloud.js — статистическое облако осколков ───────────────
//
// Портировано из Star Destroyer v21.1.1, адаптировано для Orbital Debris 3D.
// Убраны: checkDensityCloudHits, dcGetDensityAt (не нужны без целей).
//
// API:
//   dcSpawn(x0,y0,z0,vx0,vy0,vz0) — создать облако в момент взрыва
//   dcStep()                        — обновить позиции (вызывать каждый кадр)
//   dcStepAnalytical(t)             — обновить позиции по абсолютному времени t (skip-time)
//   dcReset()                       — удалить все облака
//   dcSetVisible(v)                 — показать/скрыть облако
//   dcSetPointSize(px)              — живое изменение размера точек (слайдер «Облако»)
//
// Зависит от: THREE, scene, RE, GM, J2, simTime, dvMag, atmoEnabled, airDensity, cloudSizePx
// ─────────────────────────────────────────────────────────────────────────────

// ── [v3.3.6] DC_SAMPLES убран — число частиц задаётся глобальной dcCloudN (слайдер «Частиц»)
const DC_UPDATE_EVERY = 3;     // обновлять каждые N кадров
const DC_MIN_H        = 100e3; // минимальная высота — ниже частица «гаснет»
const DC_R_OBS        = 4e8;   // граница наблюдений (м) — за ней гиперболические гаснут

let _dcClouds  = [];
let _dcTick    = 0;
let _dcVisible = true;

// ── Решение уравнения Кеплера (эллиптическое) ────────────────────────────────
function _dcSolveE(M, e) {
  let E = M;
  for (let k = 0; k < 8; k++) {
    const dE = (M - E + e * Math.sin(E)) / (1 - e * Math.cos(E));
    E += dE;
    if (Math.abs(dE) < 1e-9) break;
  }
  return E;
}

// ── Решение гиперболического уравнения Кеплера: Mh = e*sinh(H) - H ──────────
function _dcSolveH(Mh, e) {
  // Начальное приближение
  let H = Math.log(2 * Math.abs(Mh) / e + 1.8) * Math.sign(Mh);
  for (let k = 0; k < 20; k++) {
    const f  = e * Math.sinh(H) - H - Mh;
    const df = e * Math.cosh(H) - 1;
    const dH = -f / df;
    H += dH;
    if (Math.abs(dH) < 1e-9) break;
  }
  return H;
}

// ── Спавн нового облака ───────────────────────────────────────────────────────
function dcSpawn(x0, y0, z0, vx0, vy0, vz0) {
  const dv = dvMag;
  const t0 = simTime;
  const samples = [];

  const r0     = Math.sqrt(x0*x0 + y0*y0 + z0*z0);
  // v_esc в точке взрыва — для нормировки градиента цвета
  const v_esc2 = 2 * GM / r0;
  // eScale для сдвига оттенка по эксцентриситету (только для эллиптических)
  const eScale = Math.max(1e-6, 2.5 * dv / Math.sqrt(GM / r0));

  for (let i = 0; i < dcCloudN; i++) {
    // Равномерное распределение по сфере + случайная величина Δv
    const dvi    = dv * (0.8 + Math.random() * 0.4);
    const u      = Math.random() * 2 - 1;
    const phi    = Math.random() * 2 * Math.PI;
    const sinPhi = Math.sqrt(1 - u * u);
    const nx  = vx0 + dvi * sinPhi * Math.cos(phi);
    const ny  = vy0 + dvi * u;
    const nz  = vz0 + dvi * sinPhi * Math.sin(phi);

    const v2  = nx*nx + ny*ny + nz*nz;
    const r   = r0;
    const eps = v2 / 2 - GM / r;

    // Вектор момента импульса
    const hx   = y0*nz - z0*ny;
    const hy   = z0*nx - x0*nz;
    const hz   = x0*ny - y0*nx;
    const hMag = Math.sqrt(hx*hx + hy*hy + hz*hz);
    if (hMag < 1) continue;

    // Наклонение и RAAN
    const inc = Math.acos(Math.max(-1, Math.min(1, hz / hMag)));
    const Nx  = -hy, Ny = hx;
    const Nm  = Math.sqrt(Nx*Nx + Ny*Ny);
    let Om = 0;
    if (Nm > 1e-6) {
      Om = Math.acos(Math.max(-1, Math.min(1, Nx / Nm)));
      if (Ny < 0) Om = 2*Math.PI - Om;
    }

    // Вектор эксцентриситета
    const rdotv = x0*nx + y0*ny + z0*nz;
    const ex = (v2/GM - 1/r)*x0 - rdotv/GM*nx;
    const ey = (v2/GM - 1/r)*y0 - rdotv/GM*ny;
    const ez = (v2/GM - 1/r)*z0 - rdotv/GM*nz;
    const eMag = Math.sqrt(ex*ex + ey*ey + ez*ez);

    // [v3.2.6-fix] Аргумент перигея.
    // БЫЛО: om = atan2(ez*Nm, Nx*ex+Ny*ey) — неполная формула, у синусной части
    // не хватало слагаемого. При hz≈0 (наклонение основной орбиты ≈0°) ошибка
    // не проявлялась, при ненулевом наклонении давала систематическое искажение
    // om (до ~58° на 90°) — отсюда вытягивание облака в "иглу" вместо сферы
    // сразу после взрыва. Заменено на ту же конструкцию (acos + ручная
    // коррекция знака через ez), что верифицирована в density_cloud.js
    // дочернего проекта star-destroyer — там этого бага нет. Численно
    // проверено: ошибка реконструкции позиции при dt=0 равна 0 на всём
    // диапазоне наклонений 0°–179° (было — сотни–тысячи км при inc≠0).
    let om = 0;
    if (eMag > 1e-8 && Nm > 1e-6) {
      const eNdot = (Nx*ex + Ny*ey) / (Nm * eMag);
      om = Math.acos(Math.max(-1, Math.min(1, eNdot)));
      if (ez < 0) om = 2*Math.PI - om;
    }

    // Истинная аномалия в момент взрыва
    let nu0 = 0;
    if (eMag > 1e-8) {
      const rdote = (x0*ex + y0*ey + z0*ez) / (r * eMag);
      nu0 = Math.acos(Math.max(-1, Math.min(1, rdote)));
      if (rdotv < 0) nu0 = 2*Math.PI - nu0;
    }

    const hyperbolic = eps >= 0;

    if (!hyperbolic) {
      // ── Эллиптическая орбита ─────────────────────────────────────────────
      const a = -GM / (2 * eps);
      if (a <= 0 || a > 2e8) continue;

      const E0  = 2 * Math.atan2(Math.sqrt(Math.max(0,1-eMag))*Math.sin(nu0/2), Math.sqrt(1+eMag)*Math.cos(nu0/2));
      const M0  = ((E0 - eMag * Math.sin(E0)) + 2*Math.PI) % (2*Math.PI);
      const n_o = Math.sqrt(GM / (a*a*a));

      // Суборбитальная: перигей ниже поверхности Земли
      const suborbital = a * (1 - eMag) < RE;

      // Для суборбитальных вычисляем время падения аналитически:
      // находим nu при r=RE (ветвь спуска), переводим в M, считаем dt
      let t_impact = Infinity;
      if (suborbital) {
        const p_orb  = a * (1 - eMag*eMag);
        const cosNu  = Math.max(-1, Math.min(1, (p_orb/RE - 1) / eMag));
        const nu_imp = 2*Math.PI - Math.acos(cosNu); // ветвь спуска
        const E_imp  = 2*Math.atan2(Math.sqrt(1-eMag)*Math.sin(nu_imp/2),
                                     Math.sqrt(1+eMag)*Math.cos(nu_imp/2));
        const M_imp  = E_imp - eMag*Math.sin(E_imp);
        const dM     = ((M_imp - M0) + 2*Math.PI) % (2*Math.PI);
        t_impact     = dM / n_o;
      }

      samples.push({
        hyperbolic: false,
        suborbital,
        t_impact,
        a, e: eMag, n: n_o, M0, spawnT: t0,
        i: inc, Om, om,
        cosI: Math.cos(inc), sinI: Math.sin(inc),
        eps,           // для градиента цвета
      });
    } else {
      // ── Гиперболическая орбита ───────────────────────────────────────────
      // a > 0 по соглашению (полуось гиперболы), rp = a*(e-1)
      const a = GM / (2 * eps);
      if (a <= 0) continue;
      if (eMag <= 1) continue; // страховка

      // Гиперболическая аномалия H0 из истинной аномалии nu0
      // tanh(H/2) = sqrt((e-1)/(e+1)) * tan(nu/2)
      const tanHalf = Math.sqrt((eMag-1)/(eMag+1)) * Math.tan(nu0/2);
      const H0  = 2 * Math.atanh(Math.max(-0.9999, Math.min(0.9999, tanHalf)));
      const Mh0 = eMag * Math.sinh(H0) - H0;  // гиперболическая средняя аномалия
      const n_o = Math.sqrt(GM / (a*a*a));     // «гиперболическое» n (для Mh(t)=Mh0+n*dt)

      samples.push({
        hyperbolic: true,
        a, e: eMag, n: n_o, M0: Mh0, spawnT: t0,
        i: inc, Om, om,
        cosI: Math.cos(inc), sinI: Math.sin(inc),
        eps,           // для градиента цвета
      });
    }
  }

  if (!samples.length) return;

  const N   = samples.length;
  const pos = new Float32Array(N * 3);
  const col = new Float32Array(N * 3);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('color',    new THREE.BufferAttribute(col, 3));

  const points = new THREE.Points(geo, new THREE.PointsMaterial({
    size: RE * 0.013 * (cloudSizePx / 2),
    vertexColors: true,
    transparent: true, opacity: 0.85,
    sizeAttenuation: true, depthWrite: false,
  }));
  points.frustumCulled = false; // ── [v3.3.7] boundingSphere не обновляется при анимации → ложный frustum culling
  points.renderOrder = 1;
  points.visible = _dcVisible;
  scene.add(points);

  // epsScale: диапазон eps для нормировки градиента цвета.
  // Берём характерный eps эллиптических частиц — энергия на круговой орбите r0.
  const epsEll  = -GM / (2 * r0);  // eps идеально круговой орбиты на r0
  const epsHyp  = 0.5 * dv * dv;   // характерная гиперболическая энергия при dv разгоне
  const cloud = { samples, points, eScale, epsEll, epsHyp, v_esc2 };
  _dcFillArrays(cloud, pos, col, simTime);
  geo.attributes.position.needsUpdate = true;
  geo.attributes.color.needsUpdate    = true;

  _dcClouds.push(cloud);
}

// ── Заполнение позиций/цветов одного облака ───────────────────────────────────
function _dcFillArrays(cloud, pos, col, t) {
  const { samples, eScale, epsEll, epsHyp } = cloud;
  const TWO_PI = 2 * Math.PI;

  for (let i = 0; i < samples.length; i++) {
    const s  = samples[i];
    const dt = t - s.spawnT;

    if (!s.hyperbolic) {
      // ── Эллиптическая ветка ──────────────────────────────────────────────

      if (s.suborbital) {
        // ── Суборбитальная: гасим навсегда после t_impact ─────────────────
        if (dt >= s.t_impact) {
          pos[i*3] = 0; pos[i*3+1] = 0; pos[i*3+2] = 0;
          col[i*3] = 0; col[i*3+1] = 0; col[i*3+2] = 0;
          continue;
        }
        const n2  = s.n;
        const M   = ((s.M0 + n2 * dt) % TWO_PI + TWO_PI) % TWO_PI;
        const E   = _dcSolveE(M, s.e);
        const r   = s.a * (1 - s.e * Math.cos(E));
        const nu  = 2 * Math.atan2(Math.sqrt(1+s.e)*Math.sin(E/2), Math.sqrt(Math.max(0,1-s.e))*Math.cos(E/2));
        const xO  = r * Math.cos(nu);
        const yO  = r * Math.sin(nu);
        const [px, py, pz] = _dcGauss(xO, yO, s.cosI, s.sinI, s.Om, s.om);
        const [tx, ty, tz] = eciToThree(px, py, pz);
        pos[i*3]   = tx; pos[i*3+1] = ty; pos[i*3+2] = tz;
        const [r_c, g_c, b_c] = _dcHsl(0.08, 0.9, 0.55);
        col[i*3]   = r_c; col[i*3+1] = g_c; col[i*3+2] = b_c;
        continue;
      }

      let a2 = s.a, e2 = s.e;

      // Упрощённое атмосферное торможение
      if (atmoEnabled) {
        const rho_p = airDensity(a2*(1-e2) - RE);
        const da    = -(rho_p * Math.sqrt(GM/a2) * a2 / 1e4) * dt;
        a2 = Math.max(RE + 80e3, s.a + da);
        e2 = Math.max(0, s.e * (a2 / s.a));
      }
      if (a2*(1-e2) - RE < DC_MIN_H) {
        pos[i*3] = 0; pos[i*3+1] = 0; pos[i*3+2] = 0;
        col[i*3] = 0; col[i*3+1] = 0; col[i*3+2] = 0;
        continue;
      }

      // Средняя аномалия + J2-прецессия
      const n2  = Math.sqrt(GM / (a2*a2*a2));
      const M   = ((s.M0 + n2 * dt) % TWO_PI + TWO_PI) % TWO_PI;
      const p_s = a2 * (1 - e2*e2);
      const j2r = 1.5 * n2 * J2 * (RE/p_s) * (RE/p_s);
      const Om2 = s.Om - j2r * s.cosI * dt;
      const om2 = s.om + j2r * (2.5*s.sinI*s.sinI - 2) * dt;

      // Позиция в орбитальной плоскости
      const E  = _dcSolveE(M, e2);
      const nu = 2 * Math.atan2(Math.sqrt(1+e2)*Math.sin(E/2), Math.sqrt(Math.max(0,1-e2))*Math.cos(E/2));
      const r  = a2 * (1 - e2 * Math.cos(E));
      const xO = r * Math.cos(nu);
      const yO = r * Math.sin(nu);

      const [px, py, pz] = _dcGauss(xO, yO, s.cosI, s.sinI, Om2, om2);
      const [tx, ty, tz] = eciToThree(px, py, pz);
      pos[i*3]   = tx;
      pos[i*3+1] = ty;
      pos[i*3+2] = tz;

      // Цвет: градиент по eps.
      // eps < epsEll (глубоко эллиптические, низкие орбиты) → тёплый (красный/оранжевый)
      // eps → 0 (параболические) → жёлтый
      // Нормируем t=0..1 где 0=глубоко эллиптическая, 1=около параболы
      const tEps  = Math.min(1, Math.max(0, (s.eps - epsEll) / (-epsEll)));
      // Эксцентриситет добавляет небольшой сдвиг оттенка
      const eFrac = Math.min(1, s.e / eScale);
      // Тёплый диапазон: hue 0.0 (красный) → 0.12 (оранжевый) → 0.17 (жёлтый)
      const h = 0.02 + tEps * 0.15 + eFrac * 0.05;
      const dn = Math.abs(n2 - s.n);
      const tc = Math.min(1, dn / (s.n * 0.002 + dvMag / (RE + 500e3) + 1e-10));
      const [r_c, g_c, b_c] = _dcHsl(h, 0.9, 0.45 + tc * 0.40);
      col[i*3]   = r_c;
      col[i*3+1] = g_c;
      col[i*3+2] = b_c;

    } else {
      // ── Гиперболическая ветка ────────────────────────────────────────────
      // Mh(t) = Mh0 + n*dt
      const Mh  = s.M0 + s.n * dt;
      const H   = _dcSolveH(Mh, s.e);
      // nu из H: tan(nu/2) = sqrt((e+1)/(e-1)) * tanh(H/2)
      const nu  = 2 * Math.atan(Math.sqrt((s.e+1)/(s.e-1)) * Math.tanh(H/2));
      const r   = s.a * (s.e * Math.cosh(H) - 1);

      // Гасим частицы ушедшие за границу наблюдений
      if (r > DC_R_OBS) {
        pos[i*3] = 0; pos[i*3+1] = 0; pos[i*3+2] = 0;
        col[i*3] = 0; col[i*3+1] = 0; col[i*3+2] = 0;
        continue;
      }

      const xO = r * Math.cos(nu);
      const yO = r * Math.sin(nu);
      const [px, py, pz] = _dcGauss(xO, yO, s.cosI, s.sinI, s.Om, s.om);
      const [tx, ty, tz] = eciToThree(px, py, pz);
      // J2 для гиперболических не считаем — они быстро уходят
      pos[i*3]   = tx;
      pos[i*3+1] = ty;
      pos[i*3+2] = tz;

      // Цвет: холодный градиент — жёлтый (eps≈0) → голубой → синий (высокая энергия)
      // tHyp: 0=около параболы, 1=сильно гиперболическая
      const tHyp = Math.min(1, s.eps / Math.max(1, epsHyp));
      // hue: 0.17 (жёлтый) → 0.55 (голубой) → 0.67 (синий)
      const h = 0.17 + tHyp * 0.50;
      const [r_c, g_c, b_c] = _dcHsl(h, 0.85, 0.55);
      col[i*3]   = r_c;
      col[i*3+1] = g_c;
      col[i*3+2] = b_c;
    }
  }
}

// ── Матрица Гаусса: орбитальная плоскость → ECI ───────────────────────────────
function _dcGauss(xO, yO, cosI, sinI, Om, om) {
  const cosOm = Math.cos(Om), sinOm = Math.sin(Om);
  const coso  = Math.cos(om), sino  = Math.sin(om);
  const Px =  cosOm*coso - sinOm*sino*cosI;
  const Py =  sinOm*coso + cosOm*sino*cosI;
  const Pz =  sino*sinI;
  const Qx = -cosOm*sino - sinOm*coso*cosI;
  const Qy = -sinOm*sino + cosOm*coso*cosI;
  const Qz =  coso*sinI;
  return [xO*Px + yO*Qx, xO*Py + yO*Qy, xO*Pz + yO*Qz];
}

function _dcHsl(h, s, l) {
  const c = (1 - Math.abs(2*l - 1)) * s;
  const x = c * (1 - Math.abs((h*6) % 2 - 1));
  const m = l - c/2;
  let r=0, g=0, b=0;
  const hi = Math.floor(h*6) % 6;
  if      (hi===0){r=c;g=x;}
  else if (hi===1){r=x;g=c;}
  else if (hi===2){g=c;b=x;}
  else if (hi===3){g=x;b=c;}
  else if (hi===4){r=x;b=c;}
  else            {r=c;b=x;}
  return [r+m, g+m, b+m];
}

// ── dcStep: обновляем все облака (реальное время) ─────────────────────────────
function dcStep() {
  if (!_dcClouds.length) return;
  if (++_dcTick % DC_UPDATE_EVERY !== 0) return;
  for (const cloud of _dcClouds) {
    const pos = cloud.points.geometry.attributes.position;
    const col = cloud.points.geometry.attributes.color;
    _dcFillArrays(cloud, pos.array, col.array, simTime);
    pos.needsUpdate = true;
    col.needsUpdate = true;
  }
}

// ── dcStepAnalytical: обновить по абсолютному времени t (skip-time) ───────────
function dcStepAnalytical(t) {
  for (const cloud of _dcClouds) {
    const pos = cloud.points.geometry.attributes.position;
    const col = cloud.points.geometry.attributes.color;
    _dcFillArrays(cloud, pos.array, col.array, t);
    pos.needsUpdate = true;
    col.needsUpdate = true;
  }
}

// ── dcReset: удалить все облака ───────────────────────────────────────────────
function dcReset() {
  for (const cloud of _dcClouds) {
    scene.remove(cloud.points);
    cloud.points.geometry.dispose();
    cloud.points.material.dispose();
  }
  _dcClouds = [];
  _dcTick   = 0;
}

// ── dcSetVisible: показать/скрыть облако ──────────────────────────────────────
function dcSetVisible(v) {
  _dcVisible = v;
  for (const cloud of _dcClouds) cloud.points.visible = v;
}

// ── dcSetPointSize: живое изменение размера точек всех активных облаков ──────
function dcSetPointSize(px) {
  const size = RE * 0.013 * (px / 2);
  for (const cloud of _dcClouds) cloud.points.material.size = size;
}
