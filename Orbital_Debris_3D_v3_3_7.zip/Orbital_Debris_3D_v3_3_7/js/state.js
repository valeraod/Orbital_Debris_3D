// ══════════════════════════════════════════════════════════════════════════════
// STATE — глобальные переменные состояния симулятора // ── [v2.13.3]
// Загружается ДО scene3d.js (который использует RORB при инициализации).
// Classic script — все объявления глобальные.
// ══════════════════════════════════════════════════════════════════════════════

// Orbital / физические параметры
let objMass = 200;
let BCOEF   = objMass / (CD * AREA);
let orbInclDeg=0;
let HORB=500e3, RORB=RE+HORB;
let V0=Math.sqrt(GM/RORB);
let T0=2*Math.PI*Math.sqrt(RORB**3/GM);
let NFRAG=200;
let atmoEnabled=true;

// Sim runtime
let simTime=0, running=false, exploded=false, explodeTime=0;
let rafId=null /* [v3.3.0] больше не используется после Шага 5 — единый rAF-цикл в main.js не хранит свой id отдельно, requestAnimationFrame(mainLoop) самовоспроизводится изнутри. Оставлено объявление, чтобы не трогать прочий код, который мог на него ссылаться. */, lastTs=null, simSpeed=300;
let dvMag=500;
let launchDv=0;
let frags=[];
let aliveCount=0;
let fastForward=false;
let pendingExplode=false;
let focusMode=false;
let showAllOrbits=false;
let selectedFrag=null;
let selectedMain=false;
let simState='idle';
let mainObj=null;
let is2D=false;
let showFrags=true;     // видимость осколков (чекбокс «Осколки»)
let cloudSizePx=2;      // размер частиц облака, px (слайдер «Облако»)
let dcCloudN=6000;      // ── [v3.3.6] число частиц облака (слайдер «Частиц»)

// Константы рантайма
const SIM_INTERVAL=16;
const SUB_STEPS=10;
const TRAIL_LEN=18;
const ENERGY_CORRECT_INTERVAL=500;
let _skipStepCount=0;
let _skipAbort=false;
let _skipDropToRealtime=false;

// RK4 output buffer
const _rk4out=new Float64Array(6);

// ── [v3.2.3] Кэш DOM-элементов HUD, обновляемых в hot path (render3D/render2D,
// 60 раз/сек). Положен в state.js (а не в ui.js/main.js), т.к. он загружается
// первым из всех скриптов — scene3d.js и scene2d.js (подключены раньше ui.js
// и main.js) обращаются к DOM.* внутри своих render-функций, которые вызываются
// уже после полной загрузки всех скриптов, так что порядок объявления здесь
// не создаёт проблемы доступа. Кнопки/чекбоксы/слайдеры в ui.js, трогаемые
// только по клику пользователя, в этот кэш намеренно НЕ входят (см. REFACTOR_PLAN_v3.2.md, Шаг 3).
const DOM = {
  ht: document.getElementById('ht'),
  hv: document.getElementById('hv'),
  hh: document.getElementById('hh'),
  hvel: document.getElementById('hvel'),
  hz: document.getElementById('hz'),
  hudDeorbit: document.getElementById('hud-deorbit'),
  hudEscape: document.getElementById('hud-escape'),
};
