// ══════════════════════════════════════════════════════════════════════════════
// SCENE 2D — Canvas2D renderer: камера2D, звёзды, орбиты, render2D, picking // ── [v3.0.3]
// Classic script (no ES modules) — declarations are global.
// Зависит от: physics.js (orbitalElements2D, orbitalElements3D, mulberry32, RE, RORB, GM, R_OBS),
// scene3d.js (fragColorHex — не используется здесь напрямую, оставлено для справки).
// Глобальные переменные состояния (frags, mainObj, simTime, exploded, explodeTime, T0, atmoEnabled,
// showAllOrbits, selectedFrag, selectedMain, focusMode, objSizePx, TRAIL_LEN) и функции
// (formatTime, updateFragInfo, updateFocusBtn, setFocusMode) — объявлены в index.html (доступны
// к моменту вызова, см. ТЗ этап 4).
// drag2/pinch2/touch2 — переменные для мыши/тача 2D — в input.js (этап 6), здесь НЕ объявлены.
// ══════════════════════════════════════════════════════════════════════════════
const canvas2=document.getElementById('c2d');
const ctx2=canvas2.getContext('2d');
const DPR=Math.min(window.devicePixelRatio||1,2);
let W2=0, H2=0;

// 2D camera state (independent from 3D)
let zoom2=1.0, camX2=0, camY2=0;
// Переменные drag2/pinch2/touch2 (пан/пинч для 2D) — в input.js (этап 6)

function resize2D(){
  const cw=document.getElementById('cw');
  W2=cw.offsetWidth; H2=cw.offsetHeight;
  canvas2.width=W2*DPR; canvas2.height=H2*DPR;
  ctx2.setTransform(DPR,0,0,DPR,0,0);
}

// Seeded starfield for 2D (static positions)
let stars2=null;
function buildStars2(){
  const rng=mulberry32(42);
  stars2=[];
  for(let i=0;i<300;i++){
    stars2.push({x:rng(),y:rng(),r:rng()*1.3,a:0.2+rng()*0.5});
  }
}

function S2_0(){return Math.min(W2,H2)*0.44/RORB;}
function S2(){return S2_0()*zoom2;}
function ocx2(){return W2/2+camX2;}
function ocy2(){return H2/2+camY2;}

// 2D orbital elements (XZ plane — orbit is in XZ), imported from physics.js as orbitalElements2D

function drawFragOrbit2D(f){
  const el=orbitalElements2D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
  if(!el)return;
  const{a,e,rp,ra,omega,hyperbolic}=el;
  if(a<=0)return;
  const s=S2(), cx=ocx2(), cy=ocy2();
  const omegaScreen=Math.PI/2-omega;

  ctx2.save();
  ctx2.translate(cx,cy);
  ctx2.rotate(-omegaScreen);
  if(hyperbolic){
    // [v3.2.8] sampleOrbitLocal — см. physics.js. Знак x инвертирован (lx=-x):
    // особенность 2D screen-проекции, сохранена как было. null в массиве —
    // сигнал разрыва (точка не прошла проверку r), сбрасываем first, как
    // делал прежний инлайн-код.
    const local=sampleOrbitLocal(el,80,0.97,RE*60,R_OBS);
    ctx2.beginPath();
    let first=true;
    for(const p of local){
      if(!p){first=true;continue;}
      const lx=-p.x, ly=p.y;
      if(first){ctx2.moveTo(lx*s,ly*s);first=false;}
      else ctx2.lineTo(lx*s,ly*s);
    }
    ctx2.strokeStyle='rgba(0,255,180,0.75)';
    ctx2.lineWidth=1.5;
    ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  } else {
    if(a>1e9){ctx2.restore();return;}
    const b=a*Math.sqrt(Math.max(0,1-e*e));
    const c=a*e;
    ctx2.translate(+c*s,0);
    ctx2.beginPath();
    ctx2.ellipse(0,0,a*s,b*s,0,0,2*Math.PI);
    ctx2.strokeStyle='rgba(0,255,180,0.75)';
    ctx2.lineWidth=1.5;
    ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  }
  ctx2.restore();
}

function drawMainOrbit2D(frozen){
  if(!mainObj||!mainObj.alive)return;
  const el=orbitalElements2D(mainObj.x,mainObj.y,mainObj.z,mainObj.vx,mainObj.vy,mainObj.vz);
  if(!el)return;
  const{a,e,rp,ra,omega,hyperbolic}=el;
  if(a<=0)return;
  const s=S2(), cx=ocx2(), cy=ocy2();
  const omegaScreen=Math.PI/2-omega;
  const strokeStyle=frozen?'rgba(255,221,0,0.55)':'rgba(255,221,0,0.4)';
  ctx2.save();
  ctx2.translate(cx,cy);
  ctx2.rotate(-omegaScreen);
  if(hyperbolic){
    // [v3.2.8] sampleOrbitLocal — см. physics.js.
    const local=sampleOrbitLocal(el,80,0.97,RE*60,R_OBS);
    ctx2.beginPath();
    let first=true;
    for(const p of local){
      if(!p){first=true;continue;}
      // local orbital coords → screen (with omegaScreen rotation already applied)
      const lx=-p.x, ly=p.y;
      if(first){ctx2.moveTo(lx*s,ly*s);first=false;}
      else ctx2.lineTo(lx*s,ly*s);
    }
    ctx2.strokeStyle=strokeStyle;
    ctx2.lineWidth=frozen?1.5:1.2;
    if(frozen)ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  } else {
    if(a>1e9){ctx2.restore();return;}
    const b=a*Math.sqrt(Math.max(0,1-e*e));
    const c=a*e;
    ctx2.translate(+c*s,0);
    ctx2.beginPath();
    ctx2.ellipse(0,0,a*s,b*s,0,0,2*Math.PI);
    ctx2.strokeStyle=strokeStyle;
    ctx2.lineWidth=frozen?1.5:1.2;
    if(frozen)ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  }
  ctx2.restore();
}

// Frozen main orbit snapshot for 2D (set at explosion moment)
let frozenMainOrbit2D=null;

function freezeMainOrbit2D(){
  if(!mainObj||!mainObj.alive){frozenMainOrbit2D=null;return;}
  const el=orbitalElements2D(mainObj.x,mainObj.y,mainObj.z,mainObj.vx,mainObj.vy,mainObj.vz);
  frozenMainOrbit2D=el||null;
}

function drawFrozenMainOrbit2D(){
  if(!frozenMainOrbit2D)return;
  const{a,e,rp,ra,omega,hyperbolic}=frozenMainOrbit2D;
  if(a<=0)return;
  const s=S2(), cx=ocx2(), cy=ocy2();
  const omegaScreen=Math.PI/2-omega;
  ctx2.save();
  ctx2.translate(cx,cy);
  ctx2.rotate(-omegaScreen);
  if(hyperbolic){
    // [v3.2.8] sampleOrbitLocal — см. physics.js.
    const local=sampleOrbitLocal(el,80,0.97,RE*60,R_OBS);
    ctx2.beginPath();
    let first=true;
    for(const p of local){
      if(!p){first=true;continue;}
      const lx=-p.x, ly=p.y;
      if(first){ctx2.moveTo(lx*s,ly*s);first=false;}
      else ctx2.lineTo(lx*s,ly*s);
    }
    ctx2.strokeStyle='rgba(255,221,0,0.55)';
    ctx2.lineWidth=1.5;
    ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  } else {
    if(a>1e9){ctx2.restore();return;}
    const b=a*Math.sqrt(Math.max(0,1-e*e));
    const c=a*e;
    ctx2.translate(+c*s,0);
    ctx2.beginPath();
    ctx2.ellipse(0,0,a*s,b*s,0,0,2*Math.PI);
    ctx2.strokeStyle='rgba(255,221,0,0.55)';
    ctx2.lineWidth=1.5;
    ctx2.setLineDash([6,5]);
    ctx2.stroke();
    ctx2.setLineDash([]);
  }
  ctx2.restore();
}

function render2D(){
  ctx2.clearRect(0,0,W2,H2);
  ctx2.fillStyle='#03050f';
  ctx2.fillRect(0,0,W2,H2);

  // Stars
  if(stars2){
    for(const st of stars2){
      ctx2.fillStyle=`rgba(180,200,255,${st.a})`;
      ctx2.beginPath();
      ctx2.arc(st.x*W2,st.y*H2,st.r,0,2*Math.PI);
      ctx2.fill();
    }
  }

  const s=S2(), cx=ocx2(), cy=ocy2();

  // Reference orbit (dashed)
  ctx2.beginPath();
  ctx2.arc(cx,cy,RORB*s,0,2*Math.PI);
  ctx2.strokeStyle='rgba(74,158,255,0.28)';
  ctx2.lineWidth=1;
  ctx2.setLineDash([5,7]);
  ctx2.stroke();
  ctx2.setLineDash([]);

  // Earth glow (thin halo only — no atmosphere sphere)
  const glowR=RE*s;
  const grd=ctx2.createRadialGradient(cx,cy,glowR*0.85,cx,cy,glowR*1.18);
  grd.addColorStop(0,'rgba(74,130,255,0.18)');
  grd.addColorStop(0.5,'rgba(60,100,220,0.07)');
  grd.addColorStop(1,'rgba(30,60,180,0)');
  ctx2.beginPath();
  ctx2.arc(cx,cy,glowR*1.18,0,2*Math.PI);
  ctx2.fillStyle=grd;
  ctx2.fill();

  // Earth
  ctx2.beginPath();
  ctx2.arc(cx,cy,glowR,0,2*Math.PI);
  ctx2.fillStyle='#0d2a5c';
  ctx2.fill();
  ctx2.strokeStyle='#4a9eff';
  ctx2.lineWidth=1.5;
  ctx2.stroke();

  // Earth grid lines (simple latitude/longitude circles projected to XZ)
  ctx2.strokeStyle='rgba(26,58,106,0.4)';
  ctx2.lineWidth=0.5;
  for(let lat=-60;lat<=60;lat+=30){
    const cosLat=Math.cos(lat*Math.PI/180);
    const r=glowR*cosLat;
    if(r>2){
      ctx2.beginPath();
      ctx2.arc(cx,cy,r,0,2*Math.PI);
      ctx2.stroke();
    }
  }

  if(!exploded){
    // Main object orbit (live)
    if(mainObj&&mainObj.alive) drawMainOrbit2D(false);
    // Main object in XZ plane: x→screen x, z→screen y (inverted)
    if(mainObj&&mainObj.alive){
      const mx=cx-mainObj.z*s, my=cy+mainObj.x*s;
      // Trail
      if(mainObj.trailLen>1){
        ctx2.beginPath();
        const len=mainObj.trailLen;
        let idx=(mainObj.trailHead-len+TRAIL_LEN)%TRAIL_LEN;
        ctx2.moveTo(cx-mainObj.trail[idx*3+2]*s, cy+mainObj.trail[idx*3]*s);
        for(let k=1;k<len;k++){
          idx=(idx+1)%TRAIL_LEN;
          ctx2.lineTo(cx-mainObj.trail[idx*3+2]*s, cy+mainObj.trail[idx*3]*s);
        }
        ctx2.strokeStyle='rgba(255,220,0,0.3)';
        ctx2.lineWidth=1;
        ctx2.stroke();
      }
      // Glow
      const mainR2=objSizePx*Math.max(0.8,Math.min(2.4,1+0.7*Math.log2(Math.max(1,zoom2))));
      const glowR2=mainR2*2.8;
      const g2=ctx2.createRadialGradient(mx,my,0,mx,my,glowR2);
      g2.addColorStop(0,'rgba(255,220,0,0.35)');
      g2.addColorStop(1,'rgba(255,220,0,0)');
      ctx2.beginPath();ctx2.arc(mx,my,glowR2,0,2*Math.PI);
      ctx2.fillStyle=g2;ctx2.fill();
      // Dot — nonlinear radius: visible at all zoom levels (same as fragments)
      ctx2.beginPath();ctx2.arc(mx,my,mainR2,0,2*Math.PI);
      ctx2.fillStyle='#ffdd00';ctx2.fill();
    }
  } else {
    // Frozen main orbit (dashed)
    drawFrozenMainOrbit2D();
    // Fragments
    if(showFrags){
    for(let fi=0;fi<frags.length;fi++){
      const f=frags[fi];
      if(!f.alive)continue;
      const fx=cx-f.z*s, fy=cy+f.x*s;
      const h3d=Math.sqrt(f.x*f.x+f.y*f.y+f.z*f.z)-RE;
      const _isSelected=(fi===selectedFrag);
      let fragColor;
      if(_isSelected){
        fragColor='#ffffff';
      } else if(atmoEnabled){
        const t=Math.max(0,Math.min(1,1-(h3d-120e3)/280e3));
        const hue=f.hue*(1-t);
        fragColor=`hsl(${hue},90%,${55+15*(1-t)}%)`;
      } else {
        fragColor=`hsl(${f.hue},90%,68%)`;
      }
      // Trail
      if(f.trailLen>1){
        ctx2.beginPath();
        const len=f.trailLen;
        let idx=(f.trailHead-len+TRAIL_LEN)%TRAIL_LEN;
        ctx2.moveTo(cx-f.trail[idx*3+2]*s, cy+f.trail[idx*3]*s);
        for(let k=1;k<len;k++){
          idx=(idx+1)%TRAIL_LEN;
          ctx2.lineTo(cx-f.trail[idx*3+2]*s, cy+f.trail[idx*3]*s);
        }
        ctx2.strokeStyle=_isSelected?'rgba(255,255,255,0.4)':`hsla(${f.hue},80%,60%,0.22)`;
        ctx2.lineWidth=1;
        ctx2.stroke();
      }
      // Dot
      const fragR=objSizePx*Math.max(0.6,Math.min(1.8,0.75+0.55*Math.log2(Math.max(1,zoom2))))
        *(_isSelected?1.8:1.0);
      ctx2.beginPath();ctx2.arc(fx,fy,fragR,0,2*Math.PI);
      ctx2.fillStyle=fragColor;ctx2.fill();
    }
    }
    // All orbits
    if(showAllOrbits){
      for(let fi=0;fi<frags.length;fi++){
        if(fi===selectedFrag)continue; // selected orbit drawn separately
        const f=frags[fi];
        if(!f.alive)continue;
        const el=orbitalElements2D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
        if(!el||el.a<=0||el.a>1e9)continue;
        const{a,e,omega,hyperbolic}=el;
        const omegaScreen=Math.PI/2-omega;
        ctx2.save();
        ctx2.translate(cx,cy);
        ctx2.rotate(-omegaScreen);
        ctx2.strokeStyle='rgba(74,158,255,0.55)';
        ctx2.lineWidth=1;
        if(hyperbolic){
          // [v3.2.8] sampleOrbitLocal — см. physics.js. segs=64 здесь (не 80,
          // как в остальных 2D-функциях) — "много линий разом", см. таблицу плана.
          const local=sampleOrbitLocal(el,64,0.97,RE*60,R_OBS);
          ctx2.beginPath();let first=true;
          for(const p of local){
            if(!p){first=true;continue;}
            const lx=-p.x*s, ly=p.y*s;
            if(first){ctx2.moveTo(lx,ly);first=false;}else ctx2.lineTo(lx,ly);
          }
          ctx2.stroke();
        } else {
          const b=a*Math.sqrt(Math.max(0,1-e*e)), c=a*e;
          ctx2.translate(+c*s,0);
          ctx2.beginPath();ctx2.ellipse(0,0,a*s,b*s,0,0,2*Math.PI);
          ctx2.stroke();
        }
        ctx2.restore();
      }
    }
    // Selected orbit
    if(selectedFrag!==null&&frags[selectedFrag]?.alive){
      drawFragOrbit2D(frags[selectedFrag]);
    }
  }

  // HUD updates (shared with 3D) — см. updateHud() в ui.js (Шаг 4 рефакторинга)
  updateHud();

  // Focus tracking
  if(focusMode){
    let fx=null,fz=null;
    if(selectedFrag!==null&&frags[selectedFrag]&&frags[selectedFrag].alive){
      fx=frags[selectedFrag].x; fz=frags[selectedFrag].z;
    } else if(selectedMain&&mainObj&&mainObj.alive){
      fx=mainObj.x; fz=mainObj.z;
    }
    if(fx!==null){const s=S2();camX2=fz*s;camY2=-fx*s;}
    else setFocusMode(false);
  }
}

// 2D fragment picking
function pickFrag2D(clientX, clientY){
  const rect=canvas2.getBoundingClientRect();
  const mx=clientX-rect.left, my=clientY-rect.top;
  const s=S2(), cx=ocx2(), cy=ocy2();
  const PICK_R=12;
  let bestIdx=null, bestDist=Infinity, pickMain=false;
  // check mainObj first
  if(mainObj&&mainObj.alive&&!exploded){
    const sx=cx-mainObj.z*s, sy=cy+mainObj.x*s;
    const d=Math.hypot(mx-sx, my-sy);
    if(d<PICK_R){bestDist=d;pickMain=true;}
  }
  // check frags
  for(let i=0;i<frags.length;i++){
    const f=frags[i];
    if(!f.alive)continue;
    const sx=cx-f.z*s, sy=cy+f.x*s;
    const d=Math.hypot(mx-sx, my-sy);
    if(d<PICK_R&&d<bestDist){bestDist=d;bestIdx=i;pickMain=false;}
  }
  if(pickMain){
    selectedMain=!selectedMain; selectedFrag=null;
  } else if(bestIdx!==null){
    selectedFrag=(selectedFrag===bestIdx)?null:bestIdx; selectedMain=false;
  } else {
    selectedFrag=null; selectedMain=false;
  }
  updateFragInfo();
  updateFocusBtn();
}
