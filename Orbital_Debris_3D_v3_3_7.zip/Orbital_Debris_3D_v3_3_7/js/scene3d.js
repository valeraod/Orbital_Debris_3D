// ══════════════════════════════════════════════════════════════════════════════
// SCENE 3D — Three.js renderer: scene, camera, orbits, meshes, trails, picking, render3D, resize3D
// Classic script (no ES modules) — declarations are global.
// Зависит от: physics.js (rk4, orbitalElements3D, R_OBS, RE, GM, AREA, CD), RORB/HORB (объявлены в index.html ДО этого скрипта).
// updateFragInfo, updateFocusBtn, formatTime, setFocusMode, simTime, T0, explodeTime, frags, mainObj, selectedFrag,
// selectedMain, exploded, showAllOrbits, focusMode, atmoEnabled, TRAIL_LEN, is2D — объявлены позже в index.html (доступны к моменту вызова, см. ТЗ этап 3).
// ══════════════════════════════════════════════════════════════════════════════

// [v3.3.2-fix] ECI (Z-up, физика в physics.js/main.js/density_cloud.js) →
// Three.js (Y-up, сцена/Земля/камера здесь). Вся физика всегда в ECI;
// каждое место, кладущее координаты в THREE (mesh.position, BufferAttribute
// для точек/линий), должно проходить через этот хелпер. Раньше преобразование
// делала только updateRefOrbit() — остальные ~10 мест писали сырой ECI
// x,y,z прямо в THREE, из-за чего видимое наклонение облака/объекта/осколков
// отличалось от заданного (53° задано → 37° на экране, см. CHANGELOG v3.3.2).
function eciToThree(x,y,z){ return [x,z,-y]; }

// ══════════════════════════════════════════════════════════════════════════════
// 3D RENDERER — Three.js (unchanged from v2.5)
// ══════════════════════════════════════════════════════════════════════════════
const canvas3=document.getElementById('c3d');
const renderer=new THREE.WebGLRenderer({canvas:canvas3,antialias:true,alpha:false});
renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
renderer.setClearColor(0x03050f,1);

const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(45,1,1e3,1e9);
const _CAM_K=2*Math.tan(22.5*Math.PI/180); // 2*tan(fov/2) для fov=45
let objSizePx=2.5;
function camDistMatch(){
  const cw=document.getElementById('cw');
  const W=cw.offsetWidth||window.innerWidth,H=cw.offsetHeight||window.innerHeight;
  return RORB*H/(_CAM_K*Math.min(W,H)*0.44);
} // базовый размер объектов в пикселях (слайдер)
camera.position.set(0,0,RORB*3.2);

let camOrtho=null, orthoZoom=1.0;
function buildOrthoCamera(){
  const cw=document.getElementById('cw');
  const w=cw.offsetWidth||window.innerWidth, h=cw.offsetHeight||window.innerHeight;
  const halfH=RORB*2.4, halfW=halfH*(w/h);
  camOrtho=new THREE.OrthographicCamera(-halfW,halfW,-halfH,halfH,1e3,1e9);
  camOrtho.position.set(0,RORB*6,0);
  camOrtho.lookAt(0,0,0);
  camOrtho.up.set(0,0,-1);
}
function applyOrthoZoom(){
  if(!camOrtho)return;
  const cw=document.getElementById('cw');
  const w=cw.offsetWidth||window.innerWidth, h=cw.offsetHeight||window.innerHeight;
  const halfH=RORB*2.4/orthoZoom, halfW=halfH*(w/h);
  camOrtho.left=-halfW;camOrtho.right=halfW;
  camOrtho.bottom=-halfH;camOrtho.top=halfH;
  camOrtho.updateProjectionMatrix();
}

// Lights
const sun=new THREE.DirectionalLight(0xfff8e8,0.7);
sun.position.set(1,0.4,0.6).normalize();
scene.add(sun);
scene.add(new THREE.AmbientLight(0x2a3a5a,1.8));

// Starfield
(function(){
  const geo=new THREE.BufferGeometry();
  const pos=new Float32Array(3000);
  for(let i=0;i<1000;i++){
    const theta=Math.random()*Math.PI*2;
    const phi=Math.acos(2*Math.random()-1);
    const r=RE*30+Math.random()*RE*20;
    pos[i*3]=r*Math.sin(phi)*Math.cos(theta);
    pos[i*3+1]=r*Math.sin(phi)*Math.sin(theta);
    pos[i*3+2]=r*Math.cos(phi);
  }
  geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
  scene.add(new THREE.Points(geo,new THREE.PointsMaterial({color:0xaabbff,size:8000,sizeAttenuation:true})));
})();

// Earth
const earthGeo=new THREE.SphereGeometry(RE,32,32);
const earthMat=new THREE.MeshPhongMaterial({color:0x0d2a5c,emissive:0x071828,specular:0x0a1a33,shininess:5});
const earthMesh=new THREE.Mesh(earthGeo,earthMat);
scene.add(earthMesh);

const atmoGeo=new THREE.SphereGeometry(RE*1.025,32,32);
const atmoMat=new THREE.MeshPhongMaterial({color:0x4488ff,transparent:true,opacity:0.12,side:THREE.FrontSide,depthWrite:false});
const atmoMesh=new THREE.Mesh(atmoGeo,atmoMat);
scene.add(atmoMesh);

// Grid
(function(){
  const mat=new THREE.LineBasicMaterial({color:0x1a3a6a,transparent:true,opacity:0.5});
  for(let lat=-60;lat<=60;lat+=30){
    const phi=lat*Math.PI/180, pts=[];
    for(let lon=0;lon<=360;lon+=3){
      const t=lon*Math.PI/180;
      pts.push(new THREE.Vector3(RE*Math.cos(phi)*Math.cos(t),RE*Math.sin(phi),RE*Math.cos(phi)*Math.sin(t)));
    }
    scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),mat));
  }
  for(let lon=0;lon<360;lon+=30){
    const t=lon*Math.PI/180, pts=[];
    for(let lat=-90;lat<=90;lat+=3){
      const phi=lat*Math.PI/180;
      pts.push(new THREE.Vector3(RE*Math.cos(phi)*Math.cos(t),RE*Math.sin(phi),RE*Math.cos(phi)*Math.sin(t)));
    }
    scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),mat));
  }
})();

// Reference orbit
let refOrbitLine=null;
function updateRefOrbit(){
  if(refOrbitLine){refOrbitLine.geometry.dispose();refOrbitLine.material.dispose();scene.remove(refOrbitLine);}
  const pts=[];
  const inc=orbInclDeg*Math.PI/180;
  for(let j=0;j<=128;j++){
    const th=j/128*Math.PI*2;
    // [v3.3.4-fix] ECI (Z-up), согласовано с main.js mainPos(): эта функция
    // не была синхронизирована при восстановлении фикса v3.3.1 в main.js
    // (sin(inc)/cos(inc) в Y/Z оставались в старом, неверном порядке) —
    // отсюда видимое расхождение наклона между опорной линией (эта
    // функция) и реальной орбитой объекта (buildMainOrbitLine/mainPos).
    const ex=RORB*Math.cos(th);
    const ey=RORB*Math.sin(th)*Math.cos(inc);
    const ez=RORB*Math.sin(th)*Math.sin(inc);
    const[tx,ty,tz]=eciToThree(ex,ey,ez);
    pts.push(new THREE.Vector3(tx,ty,tz));
  }
  refOrbitLine=new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineBasicMaterial({color:0x4a9eff,transparent:true,opacity:0.3})
  );
  scene.add(refOrbitLine);
}
updateRefOrbit();

// Main object current orbit line (live solid → frozen dashed after explosion)
let mainOrbitLine=null;
let mainOrbitFrozen=false;

function buildMainOrbitLine(x,y,z,vx,vy,vz,frozen){
  if(mainOrbitLine){mainOrbitLine.geometry.dispose();mainOrbitLine.material.dispose();scene.remove(mainOrbitLine);mainOrbitLine=null;}
  const el=orbitalElements3D(x,y,z,vx,vy,vz);
  if(!el)return;
  const{a,hx,hy,hz,ex,ey,ez}=el;
  if(a<=0)return;
  const eMag=Math.sqrt(ex*ex+ey*ey+ez*ez)||1;
  const px=ex/eMag,py=ey/eMag,pz=ez/eMag;
  const qx=hy*pz-hz*py,qy=hz*px-hx*pz,qz=hx*py-hy*px;
  const qMag=Math.sqrt(qx*qx+qy*qy+qz*qz)||1;
  const qnx=qx/qMag,qny=qy/qMag,qnz=qz/qMag;
  // [v3.2.8] segs: live было 64, теперь 128 — унификация с updateSelOrbit3D/
  // buildAllOrbitLines3D (решённый вопрос Шага 1, см. physics.js sampleOrbitLocal).
  // frozen остаётся на 96 — компенсация под LineDashedMaterial, не дублирование.
  const segs=frozen?96:128;
  const local=sampleOrbitLocal(el,segs,0.98,RE*60,R_OBS);
  const pts=local.filter(Boolean).map(p=>{
    const[ex2,ey2,ez2]=[p.x*px+p.y*qnx,p.x*py+p.y*qny,p.x*pz+p.y*qnz];
    const[tx,ty,tz]=eciToThree(ex2,ey2,ez2);
    return new THREE.Vector3(tx,ty,tz);
  });
  if(pts.length<2)return;
  const mat=frozen
    ? new THREE.LineDashedMaterial({color:0xffdd00,transparent:true,opacity:0.55,dashSize:RE*0.04,gapSize:RE*0.03})
    : new THREE.LineBasicMaterial({color:0xffdd00,transparent:true,opacity:0.45});
  mainOrbitLine=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),mat);
  if(frozen)mainOrbitLine.computeLineDistances();
  scene.add(mainOrbitLine);
}

function updateMainOrbitLine(){
  if(mainOrbitFrozen)return; // don't rebuild frozen orbit
  if(!mainObj||!mainObj.alive){mainOrbitFrozen=false;return;}
  buildMainOrbitLine(mainObj.x,mainObj.y,mainObj.z,mainObj.vx,mainObj.vy,mainObj.vz,false);
}

function freezeMainOrbit(){
  if(!mainObj)return;
  mainOrbitFrozen=true;
  buildMainOrbitLine(mainObj.x,mainObj.y,mainObj.z,mainObj.vx,mainObj.vy,mainObj.vz,true);
}
const mainGeo=new THREE.SphereGeometry(1,8,8);
const mainMat=new THREE.MeshBasicMaterial({color:0xffdd00});
const mainMesh=new THREE.Mesh(mainGeo,mainMat);
scene.add(mainMesh);
const mainGlowGeo=new THREE.SphereGeometry(1,8,8);
const mainGlowMat=new THREE.MeshBasicMaterial({color:0xffdd00,transparent:true,opacity:0.25});
const mainGlowMesh=new THREE.Mesh(mainGlowGeo,mainGlowMat);
scene.add(mainGlowMesh);

// Fragment meshes
const _sharedFragGeo=new THREE.SphereGeometry(1,6,6);
const fragMeshes=[];
let selOrbitLine=null;
const allOrbitLines=[];

function build3DFragMeshes(){
  fragMeshes.forEach(m=>{m.material.dispose();scene.remove(m);});
  fragMeshes.length=0;
  for(let i=0;i<frags.length;i++){
    const mat=new THREE.MeshBasicMaterial({color:0xffee88});
    const m=new THREE.Mesh(_sharedFragGeo,mat);
    fragMeshes.push(m);
    scene.add(m);
    frags[i]._lastColor=-1;
  }
}

function fragColorHex(f){
  if(!f.alive)return 0x333344;
  const h=Math.sqrt(f.x*f.x+f.y*f.y+f.z*f.z)-RE;
  if(atmoEnabled){
    const blend=Math.max(0,Math.min(1,1-(h-120e3)/280e3));
    if(blend>0.5)return 0xff4400;
  }
  return 0xffee88;
}

// Trail lines
const trailLines=[];
let mainTrailLine=null;

function build3DTrailLines(){
  trailLines.forEach(l=>scene.remove(l));trailLines.length=0;
  for(let i=0;i<frags.length;i++){
    const mat=new THREE.LineBasicMaterial({color:0xffaa22,transparent:true,opacity:0.5});
    const positions=new Float32Array(TRAIL_LEN*3);
    const geo=new THREE.BufferGeometry();
    const attr=new THREE.BufferAttribute(positions,3);
    attr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position',attr);
    geo.setDrawRange(0,0);
    const line=new THREE.Line(geo,mat);
    line._posAttr=attr;
    trailLines.push(line);
    scene.add(line);
  }
}

function buildMainTrailLine(){
  if(mainTrailLine){mainTrailLine.geometry.dispose();mainTrailLine.material.dispose();scene.remove(mainTrailLine);}
  const positions=new Float32Array(TRAIL_LEN*3);
  const geo=new THREE.BufferGeometry();
  const attr=new THREE.BufferAttribute(positions,3);
  attr.setUsage(THREE.DynamicDrawUsage);
  geo.setAttribute('position',attr);
  geo.setDrawRange(0,0);
  mainTrailLine=new THREE.Line(geo,new THREE.LineBasicMaterial({color:0xffdd00,transparent:true,opacity:0.5}));
  mainTrailLine._posAttr=attr;
  scene.add(mainTrailLine);
}

function updateMainTrail(){
  if(!mainTrailLine||!mainObj||!mainObj.alive||mainObj.trailLen<2){
    if(mainTrailLine)mainTrailLine.visible=false;return;
  }
  mainTrailLine.visible=true;
  const arr=mainTrailLine._posAttr.array;
  const len=mainObj.trailLen;
  let idx=(mainObj.trailHead-len+TRAIL_LEN)%TRAIL_LEN;
  for(let k=0;k<len;k++){
    const base=idx*3;
    const[tx,ty,tz]=eciToThree(mainObj.trail[base],mainObj.trail[base+1],mainObj.trail[base+2]);
    arr[k*3]=tx;arr[k*3+1]=ty;arr[k*3+2]=tz;
    idx=(idx+1)%TRAIL_LEN;
  }
  mainTrailLine._posAttr.needsUpdate=true;
  mainTrailLine.geometry.setDrawRange(0,len);
}

function updateTrails(){
  for(let i=0;i<frags.length;i++){
    const f=frags[i], line=trailLines[i];
    if(!f.alive||f.trailLen<2||!showFrags){line.visible=false;continue;}
    line.visible=true;
    const arr=line._posAttr.array;
    const len=f.trailLen;
    let idx=(f.trailHead-len+TRAIL_LEN)%TRAIL_LEN;
    for(let k=0;k<len;k++){
      const base=idx*3;
      const[tx,ty,tz]=eciToThree(f.trail[base],f.trail[base+1],f.trail[base+2]);
      arr[k*3]=tx;arr[k*3+1]=ty;arr[k*3+2]=tz;
      idx=(idx+1)%TRAIL_LEN;
    }
    line._posAttr.needsUpdate=true;
    line.geometry.setDrawRange(0,len);
    const newColor=fragColorHex(f);
    if(f._lastTrailColor!==newColor){line.material.color.setHex(newColor);f._lastTrailColor=newColor;}
  }
}

// Camera orbit
let camTheta=0, camPhi=Math.PI/4, camDist=RORB*2.745;
let camTargetX=0, camTargetY=0, camTargetZ=0; // pan offset
let dragActive=false, dragBtn=-1, lastMX=0, lastMY=0;
let dragMode='orbit'; // 'orbit' or 'pan'
let mouseDownX=0, mouseDownY=0, mouseMoved=false;

function updateCamera(){
  camera.position.set(
    camTargetX+camDist*Math.sin(camPhi)*Math.cos(camTheta),
    camTargetY+camDist*Math.cos(camPhi),
    camTargetZ+camDist*Math.sin(camPhi)*Math.sin(camTheta)
  );
  camera.lookAt(camTargetX,camTargetY,camTargetZ);
}
updateCamera();

function activeCamera3D(){return is2D&&camOrtho?camOrtho:camera;}

// Raycaster
const raycaster=new THREE.Raycaster();
raycaster.params.Points={threshold:RE*0.05};

function hitTestEarth(clientX, clientY){
  const rect=canvas3.getBoundingClientRect();
  const mouse=new THREE.Vector2(
    ((clientX-rect.left)/rect.width)*2-1,
    -((clientY-rect.top)/rect.height)*2+1
  );
  raycaster.setFromCamera(mouse, camera);
  return raycaster.intersectObject(earthMesh).length>0;
}

// Pan: move camTarget in camera's right/up plane
function applyPan(dxPx, dyPx){
  // pan speed proportional to distance
  const speed=camDist*0.0007;
  // camera right vector
  const sinT=Math.sin(camTheta), cosT=Math.cos(camTheta);
  const sinP=Math.sin(camPhi),   cosP=Math.cos(camPhi);
  // right = cross(up_world, forward) -- but easier: derivative of position wrt theta
  const rx= Math.sin(camTheta);
  const ry= 0;
  const rz=-Math.cos(camTheta);
  // up in camera = derivative of position wrt -phi, normalised
  const ux=-cosP*Math.cos(camTheta);
  const uy= sinP;
  const uz=-cosP*Math.sin(camTheta);
  camTargetX+=(-dxPx*rx - dyPx*ux)*speed;
  camTargetY+=(-dxPx*ry - dyPx*uy)*speed;
  camTargetZ+=(-dxPx*rz - dyPx*uz)*speed;
}

function updateSelOrbit3D(){
  if(selOrbitLine){scene.remove(selOrbitLine);selOrbitLine=null;}
  if(selectedFrag===null||!frags[selectedFrag]||!frags[selectedFrag].alive)return;
  const f=frags[selectedFrag];
  const el=orbitalElements3D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
  if(!el)return;
  const{a,hx,hy,hz,ex,ey,ez}=el;
  const eMag=Math.sqrt(ex*ex+ey*ey+ez*ez)||1;
  const px=ex/eMag,py=ey/eMag,pz=ez/eMag;
  const qx=(hy*pz-hz*py),qy=(hz*px-hx*pz),qz=(hx*py-hy*px);
  const qMag=Math.sqrt(qx*qx+qy*qy+qz*qz)||1;
  const qnx=qx/qMag,qny=qy/qMag,qnz=qz/qMag;
  // [v3.2.8] a>1e9 и r>R_OBS на эллиптической ветке раньше здесь не проверялись
  // (в отличие от buildMainOrbitLine/buildAllOrbitLines3D) — недосмотр, решено
  // унифицировать через sampleOrbitLocal (см. physics.js).
  const local=sampleOrbitLocal(el,128,0.98,RE*60,R_OBS);
  const pts=local.filter(Boolean).map(p=>{
    const[ex2,ey2,ez2]=[p.x*px+p.y*qnx,p.x*py+p.y*qny,p.x*pz+p.y*qnz];
    const[tx,ty,tz]=eciToThree(ex2,ey2,ez2);
    return new THREE.Vector3(tx,ty,tz);
  });
  if(pts.length<2)return;
  selOrbitLine=new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineBasicMaterial({color:0x00ffb4,transparent:true,opacity:0.8})
  );
  scene.add(selOrbitLine);
}

// [v3.2.9] Шаг 2 REFACTOR_PLAN_v3.2.md, Вариант А: обновлять линии "Все орбиты"
// не каждый кадр, а раз в ALL_ORBITS_UPDATE_EVERY кадров — по аналогии с
// DC_UPDATE_EVERY в density_cloud.js. При showAllOrbits=true и большом числе
// осколков пересоздание geometry/material для каждой линии каждый кадр было
// заметной лишней нагрузкой. Между обновлениями старые линии остаются на
// экране как есть — на медленно меняющихся орбитах незаметно, при активном
// атмосферном торможении возможен лаг до N кадров (обсуждено, принято).
const ALL_ORBITS_UPDATE_EVERY = 3;
let _allOrbitsTick = 0;

// Внутренняя очистка (без сброса тика) — используется самим buildAllOrbitLines3D
// перед перестроением геометрии раз в N кадров.
function _clearAllOrbitLines3DGeometry(){
  allOrbitLines.forEach(l=>{l.geometry.dispose();l.material.dispose();scene.remove(l);});
  allOrbitLines.length=0;
}

// Внешняя очистка — вызывается при выключении чекбокса "Все орбиты"
// (toggleAllOrbits в ui.js) и при ресете. Сбрасывает тик, чтобы следующее
// включение сразу построило линии, без задержки в N кадров.
function clearAllOrbitLines3D(){
  _clearAllOrbitLines3DGeometry();
  _allOrbitsTick=0;
}

function buildAllOrbitLines3D(){
  // [v3.2.9] Проверка ДО инкремента (не после) — первый вызов после сброса
  // тика (_allOrbitsTick=0, см. clearAllOrbitLines3D) сразу строит линии,
  // без задержки в N кадров при включении чекбокса "Все орбиты".
  if(_allOrbitsTick++ % ALL_ORBITS_UPDATE_EVERY !== 0) return;
  _clearAllOrbitLines3DGeometry();
  const mat=new THREE.LineBasicMaterial({color:0x4a9eff,transparent:true,opacity:0.55});
  for(const f of frags){
    if(!f.alive||f.beyond)continue;
    const el=orbitalElements3D(f.x,f.y,f.z,f.vx,f.vy,f.vz);
    if(!el||el.a<=0)continue;
    const{hx,hy,hz,ex,ey,ez}=el;
    const eMag=Math.sqrt(ex*ex+ey*ey+ez*ez)||1;
    const px=ex/eMag,py=ey/eMag,pz=ez/eMag;
    const qx=(hy*pz-hz*py),qy=(hz*px-hx*pz),qz=(hx*py-hy*px);
    const qMag=Math.sqrt(qx*qx+qy*qy+qz*qz)||1;
    const qnx=qx/qMag,qny=qy/qMag,qnz=qz/qMag;
    const local=sampleOrbitLocal(el,128,0.98,RE*60,R_OBS);
    const pts=local.filter(Boolean).map(p=>{
      const[ex2,ey2,ez2]=[p.x*px+p.y*qnx,p.x*py+p.y*qny,p.x*pz+p.y*qnz];
      const[tx,ty,tz]=eciToThree(ex2,ey2,ez2);
      return new THREE.Vector3(tx,ty,tz);
    });
    if(pts.length<2)continue;
    const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),mat.clone());
    allOrbitLines.push(line);
    scene.add(line);
  }
}

// 3D resize
function resize3D(){
  if(!window._camUserZoomed) camDist=camDistMatch();
  const cw=document.getElementById('cw');
  const w=cw.offsetWidth, h=cw.offsetHeight;
  renderer.setSize(w,h,false);
  camera.aspect=w/h;
  camera.updateProjectionMatrix();
  if(camOrtho)applyOrthoZoom();
}

let earthRot=0;
function render3D(){
  earthRot+=0.0002;
  earthMesh.rotation.y=earthRot;
  atmoMesh.rotation.y=earthRot*0.98;

  if(!exploded){
    if(mainObj&&mainObj.alive){
      {
        const[tx,ty,tz]=eciToThree(mainObj.x,mainObj.y,mainObj.z);
        mainMesh.position.set(tx,ty,tz);
        mainGlowMesh.position.set(tx,ty,tz);
      }
      mainMesh.visible=true;mainGlowMesh.visible=true;
      // Nonlinear scale: visible size grows slowly with distance (same as fragments)
      const _zoom3=camDistMatch()/camDist;
      const _minePx=objSizePx*Math.max(0.8,Math.min(2.4,1+0.7*Math.log2(Math.max(1,_zoom3))));
      const _mineWR=_minePx*camDist*_CAM_K/renderer.domElement.height;
      mainMesh.scale.setScalar(_mineWR);
      mainGlowMesh.scale.setScalar(_mineWR*2.8);
    } else {
      mainMesh.visible=false;mainGlowMesh.visible=false;
    }
    updateMainTrail();
    updateMainOrbitLine();
  } else {
    mainMesh.visible=false;mainGlowMesh.visible=false;
    for(let i=0;i<frags.length;i++){
      const f=frags[i],m=fragMeshes[i];
      if(!m)continue;
      if(f.alive&&!f.beyond&&showFrags){
        {
          const[tx,ty,tz]=eciToThree(f.x,f.y,f.z);
          m.position.set(tx,ty,tz);
        }
        m.visible=true;
        const _zoom3f=camDistMatch()/camDist;
        const _isSelected=(i===selectedFrag);
        const _fragPx3=objSizePx*Math.max(0.6,Math.min(1.8,0.75+0.55*Math.log2(Math.max(1,_zoom3f))))
          *(_isSelected?1.8:1.0);
        const _fragWR=_fragPx3*camDist*_CAM_K/renderer.domElement.height;
        m.scale.setScalar(_fragWR);
        const newColor=_isSelected?0xffffff:fragColorHex(f);
        if(f._lastColor!==newColor){m.material.color.setHex(newColor);f._lastColor=newColor;}
      } else {m.visible=false;}
    }
    updateTrails();
    if(showAllOrbits) buildAllOrbitLines3D();
    else clearAllOrbitLines3D();
    if(selectedFrag!==null&&frags[selectedFrag]?.alive){
      updateSelOrbit3D();updateFragInfo();
    }
  }

  updateHud();

  // Focus tracking
  if(focusMode){
    let fx=null,fy=null,fz=null;
    if(selectedFrag!==null&&frags[selectedFrag]&&frags[selectedFrag].alive){
      const f=frags[selectedFrag];[fx,fy,fz]=eciToThree(f.x,f.y,f.z);
    } else if(selectedMain&&mainObj&&mainObj.alive){
      [fx,fy,fz]=eciToThree(mainObj.x,mainObj.y,mainObj.z);
    }
    if(fx!==null){camTargetX=fx;camTargetY=fy;camTargetZ=fz;updateCamera();}
    else setFocusMode(false);
  }

  renderer.render(scene,activeCamera3D());
}

